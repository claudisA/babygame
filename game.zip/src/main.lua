
function __G__TRACKBACK__(errorMessage)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(errorMessage) .. "\n")
    print(debug.traceback("", 2))
    print("----------------------------------------")
end

local path = getWritablePath()
package.path = package.path .. ";" .. path .. "/download/src/"  
cc.FileUtils:getInstance():setPopupNotify(false)
require("app.MyApp").new():run()
