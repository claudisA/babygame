
require("config")
require("cocos.init")
require("framework.init")

local MyApp = class("MyApp", cc.mvc.AppBase)

--[[
gameState = require(cc.PACKAGE_NAME ..".cc.utils.GameState")
gameData = {}

--初始化数据文件
gameState.init(function(event)
	local  str = nil

	if event.errorCode then
		print("ERROR, load:" .. event.errorCode)
		return
	end

	if "load" == event.name then
		local str = crypto.decryptXXTEA(event.values.data, "claudis")
        str = json.decode(str)
        --dump(str, "load data:")
        return str
	elseif "save" == event.name then
		local str = json.encode(event.values)
        if str then
        	--dump(str, "save data:")
            str = crypto.encryptXXTEA(str, "claudis")
        else
        	print("ERROR, encode fail")
            return
        end

		return str
	end
end, "gamedata.bat", "ptyl")

local playerJson= gameState.load()
if playerJson == nil then --第一次运行游戏
    gameData.aaa = 1000
    GameState.save(gameData)
end

if io.exists(gameState.getGameStatePath()) then
    --gameData = gameState.load()
    --gameData.isBabyGame = true
	--gameState.save(gameData)
end
--]]

function MyApp:ctor()
    MyApp.super.ctor(self)
end

function MyApp:run()
    local path = device.writablePath
    cc.FileUtils:getInstance():addSearchPath(path .. "/download/res/")
    cc.FileUtils:getInstance():addSearchPath(path .. "/download/res/clown")

    audio.preloadMusic("letters/sound/bg_music.mp3")
    audio.preloadSound("letters/sound/full_stampede.mp3")
    audio.preloadSound("letters/sound/word_celebration.mp3")
    audio.preloadSound("letters/sound/sentence_celebration.mp3")
    audio.preloadSound("letters/sound/word_select.mp3")

    audio.preloadMusic("sound/particle_sfx.mp3")
    audio.preloadMusic("sound/gameplay.mp3")
    audio.preloadSound("sound/bird_happy.wav")
    audio.preloadSound("sound/bird_sad.wav")
    audio.preloadSound("sound/SFX_Yeah.mp3")
    audio.preloadSound("sound/win.wav")

    audio.preloadSound("balloon/sound/sound.balloon.runaway.mp3")
    

    self:enterScene("MainScene")
end

return MyApp
