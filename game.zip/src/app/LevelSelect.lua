require("app.LevelButton")
require("app.GlobalData")
require("app.HomeGamesButton")
require("app.utils.luaUtils")

local BubbleButton = import("app.common.BubbleButton")

LevelSelect = class("LevelSelect", function()
    return display.newLayer()
end)

function LevelSelect:ctor(array,idx)
    local bg = display.newSprite(levelselect_bg[idx])
    :pos(display.cx, display.cy)

    local size = bg:getContentSize()
    bg:setScale(display.cx * 2 / size.width, display.cy * 2 / size.height)
    bg:addTo(self)

    self.levelsBtn = {}

	for i=1,#array do
        local x = 230 + (i - (getIntPart((i - 1)/ 3)) * 3) * 170
        local y = display.cy * 2 - 80 + (getIntPart((i - 1)/ 3)) * (-210)
        self.levelsBtn[#self.levelsBtn + 1] = HomeGamesButton.new(array[i][1],array[i][2],function ()
            if #array[i][4] ~= 0 then
                self:setButtonEnabled(false)
                require(array[i][3]).new(array[i][4][1]):addTo(self:getParent())
            else 
                self:setButtonEnabled(false)
                require(array[i][3]).new():addTo(self:getParent())
            end
         end)
        :pos(x,y)
        :addTo(self)
    end

    --添加返回按钮
    self.backButton = BubbleButton.new({
        image = "home/back.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
            require("app.HomePage").new():addTo(self:getParent())
            self:removeFromParent()
        end,
    })
    :pos(340, 50)
    :addTo(self)

    --打开节点进入退出响应
    self:setNodeEventEnabled(true)

    g_selectLevel = self
end

function LevelSelect:setButtonEnabled(able)
    for i=1,#self.levelsBtn do
        self.levelsBtn[i]:setButtonEnabled(able)
    end
end

function LevelSelect:onEnter()

end

function LevelSelect:onExit()
    g_selectLevel = nil
end

return LevelSelect