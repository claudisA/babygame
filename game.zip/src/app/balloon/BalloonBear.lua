require("app.balloon.data")
require("app.luaCallJava")
local BubbleButton = import("app.common.BubbleButton")

BalloonBear = class("BalloonBear", function()
    return display.newSprite()
end)


function BalloonBear:ctor(param)

	self.trackarray = 
	{
		"bezier",
	}

	self.flagword = nil
	self.balloon = nil
	self.bear = nil
	self.wordSprite = nil
	self.sballoon_name = nil
	self.sword_name = nil
	self.sbear_name = nil

	
	--[[
	self.sballon_name = string.format("balloon/balloon%02X.png",math.random(0,6))
	self.balloon = display.newSprite(self.sballon_name)
	:pos(0, 80)
	:setScale(0.4)
	:addTo(self);
	--]]

    --把气球设置成按钮，保证可以点击消除，防止网速过慢时无法进行语音消除
    local imgIndex = math.random(0,4)
    self.sballon_name = string.format("balloon/balloon%02d_01.png",imgIndex)
	self.balloon = BubbleButton.new({
        image = self.sballon_name,
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.balloon:setButtonEnabled(false)
        end,
        listener = function()
        	--self:playDigitalSound(self.flagword)
        	playSound(self.flagword)
        	local event = cc.EventCustom:new(MSG_CLICK_DIGITAL_EVEN)
	        event.userdata = self
	        -- 1.获取事件分发器  : EventDispatcher
    		local dispatcher = cc.Director:getInstance():getEventDispatcher()
	    	dispatcher:dispatchEvent(event)

	    	self.balloon:setButtonEnabled(false)
	    	audio.playSound("balloon/sound/sound.balloon.runaway.mp3")
        end,
    })
    :pos(0, 140)
    :setZOrder(10)
    :setScale(1.0)
    :addTo(self)

    --添加气球绳子
    local balloonRope_name = string.format("balloon/balloon%02d_02.png",imgIndex)
    display.newSprite(balloonRope_name)
    :pos(-10, -142)
    :setZOrder(5)
    :setScale(1.0)
    :addTo(self.balloon)

    --添加数字\字母\中文字
    local index = nil
    if param == 1 then
    	index = math.random(1,10)
    elseif param == 2 then
    	index = math.random(11,20)
    elseif param == 3 then
    	index = math.random(21,46)
    elseif param == 4 then
    	index = math.random(47,72)
    end
    self.flagword = flagword_array[index]
	self.sword_name = string.format("word/word_%03d.png",index)
	self.wordSprite = display.newSprite(self.sword_name)
	:pos(0, 0)
	:setScale(1.0)
	:addTo(self.balloon);

	self.sbear_name = string.format("balloon/candy_%02d.png",math.random(1,8))
	self.bear = display.newSprite(self.sbear_name)
	:pos(0, -30)
	:setScale(0.5)
	:setZOrder(16)
	:addTo(self);

	local scheduler = cc.Director:getInstance():getScheduler()
	self.schedulerID = nil  
	self.schedulerID = scheduler:scheduleScriptFunc(function()
	--self:detect()
	end,0.5,false)  
end

--如果精灵超出了屏幕就清除
function BalloonBear:detect()
	if self:getPositionY() > HIGHEST_MOVE_Y then

		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)

		local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    	local event = cc.EventCustom:new(TAG_BALLOONBEAR_REMOVE)
    	event.userdata = self
    	eventDispatcher:dispatchEvent(event) 
	end
end

function BalloonBear:decompose()
	--气球往上飞走
	local function balloonUp()
		 --"height" = 477
		 --"width"  = 304
		local size = self.balloon:getContentSize()
		local y = self.balloon:getPositionY()
		local node_point = self:convertToNodeSpace(cc.p(0, display.cy * 2))
		self.balloon:moveBy(3.0, 0, node_point.y - y + size.height / 2)
	end

	--小熊往下吊
	local function bearDown()
		local size = self.bear:getContentSize()
		local y = self.bear:getPositionY()
		local node_point = self:convertToNodeSpace(cc.p(0, 0))
		self.bear:moveBy(3.0, 0, node_point.y - y - size.height / 2)
	end

	--小熊掉落地面动画
	local function bearOnGround()
		
	end

	--停止精灵的动作
	local function stopTrackAction()
		local action = self:getActionByTag(TAG_BALLOONBEAR_ACTION)
		local actionManager = cc.Director:getInstance():getActionManager()
		actionManager:removeAction(action)
	end

	--数字移动到屏幕中点
	local function hideDigital()
		--self.wordSprite:setVisible(false)
		self:removeFromParent()
	end
	local function digitalMove()
		self.wordSprite:removeFromParent()

		local x = self.balloon:getPositionX()
        local y = self.balloon:getPositionY()
		self.wordSprite = display.newSprite(self.sword_name)
		:pos(x, y)
		:setZOrder(20)
		:setScale(0.4)
		:addTo(self);

		local node_point = self:convertToNodeSpace(cc.p(display.cx, display.cy))
		local action1 = CCJumpTo:create(0.6,cc.p(node_point.x,node_point.y),30, 2)
		local action2 = CCScaleTo:create(0.6, 2.5)
		local sequence = cc.Sequence:create(action1,
			action2,
			cc.DelayTime:create(0.3),
			cc.CallFunc:create(handler(self, hideDigital)),
			nil)  
		self.wordSprite:runAction(sequence)
	end

	local sequence = cc.Sequence:create(
	cc.CallFunc:create(handler(self, balloonUp)),
	cc.DelayTime:create(0.3),
	cc.CallFunc:create(handler(self, stopTrackAction)),
	cc.CallFunc:create(handler(self, digitalMove)),
	cc.CallFunc:create(handler(self, bearDown)),
	nil)

	self:runAction(sequence)

end


--以某种轨迹运动
function BalloonBear:runAsTrack(track,position)
	if self.trackarray[1] == track then
		local bezier = self:getBezier(position)
		bezier:setTag(TAG_BALLOONBEAR_ACTION)
		self:runAction(bezier)
	end
end

--生成贝塞尔运动
function BalloonBear:getBezier(position)
	local bezier = {
		position,
    	BEZIER_CONTROL_POINT(position),
    	BEZIER_END_POINT(position),
  	}
  	-- 以持续时间和贝塞尔曲线的配置结构体为参数创建动作
  	local bezierForward = cc.BezierTo:create(MOVING_TIME, bezier)

  	return bezierForward 
end

--播放数字语音
--[[
function BalloonBear:playDigitalSound(digital)
	if device.platform == "android" then
	  local javaClassName = "org/cocos2dx/lua/AppActivity"
	  local javaMethodName = "SpeechSynthesis"
	  local javaParams = {digital,0}
	  local javaMethodSig = "(Ljava/lang/String;I)V"
	  luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
	end
end
--]]


return  BalloonBear