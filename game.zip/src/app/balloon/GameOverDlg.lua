require("app.balloon.data")

local BubbleButton = import("app.common.BubbleButton")

GameOverDlg = class("GameOverDlg", function()
    return display.newLayer()
end)

function GameOverDlg:ctor()

	cc.LayerColor:create(cc.c4b(0,0,0,220))
	:addTo(self)

	local bg = display.newSprite("common/gameover_bg.png")
    :pos(display.cx, display.cy)
	:addTo(self)

    --播放粒子效果
    local particle1 = cc.ParticleSystemQuad:create("particles/snow.plist")
    :pos(display.cx * 2 / 3 * 1 - display.cx,display.cy - 100)
    :addTo(self)

    local particle2 = cc.ParticleSystemQuad:create("particles/snow.plist")
    :pos(display.cx * 2 / 3 * 2 - display.cx,display.cy - 100)
    :addTo(self)


    -- 1.获取事件分发器  : EventDispatcher
    local dispatcher = cc.Director:getInstance():getEventDispatcher()

    -- 2.创建发送消息
    local event = cc.EventCustom:new(STOP_CREATE_SPRITE)
    dispatcher:dispatchEvent(event) 

	self.continueButton = BubbleButton.new({
            image = "common/continue.png",
            sound = nil,
            prepare = function()
                --audio.playSound(GAME_SFX.tapButton)
                self.continueButton:setButtonEnabled(false)
            end,
            listener = function()
                if g_mainScene ~= nil then

                    local layer = self:getParent()
                    if layer.param ~= nil then
                        local newLayer = require(self:getParent().modname).new(layer.param)
                        :addTo(g_mainScene)
                    else
                        local newLayer = require(self:getParent().modname).new()
                        :addTo(g_mainScene)
                    end
                    
                    layer:removeFromParent()
                end
            end,
        })
        :pos(display.cx - 200, display.cy)
        :addTo(self)

	self.backButton = BubbleButton.new({
        image = "common/back.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
            local parent = self:getParent() 
            --停止播放生成声音
            stopSpeeking()
            if g_selectLevel ~= nil then
                g_selectLevel:setButtonEnabled(true)
            end
            parent:removeFromParent()
        end,
    })
    :pos(display.cx + 200, display.cy)
    :addTo(self)

end


return GameOverDlg