require("app.GlobalData")
require("app.luaCallJava")
require("app.balloon.data")
require("app.balloon.GameOverDlg")
local BubbleButton = import("app.common.BubbleButton")

BalloonBearLayer = class("BalloonBearLayer", function()
    return display.newLayer()
end)

function BalloonBearLayer:ctor(param)
	self.param = param
	self.modname = "app.balloon.BalloonBearLayer"
	self.gamefinish = false

	local bg = display.newSprite("balloon/candy_bg.png")
	:pos(display.cx, display.cy)

	local size = bg:getContentSize()
	bg:setScale(display.cx * 2 / size.width, display.cy * 2 / size.height)
	bg:addTo(self)


	--获取网络状态
	if getNetWorkStatus() == false then
		showTip(StoryData["network_tips"][1])
		--直接展示引导
	else
	    --播放游戏引导
		playSound(StoryData["study_digital"][1])
	end



	--添加移动云彩
    self:moveCloud(-100,display.cy + 150,125)
    self:moveCloud(100,display.cy + 250,200)
    self:moveCloud(50,display.cy + 50,100)
	self.balloonbear_count = 0

	--保存精灵的数组
	self.balloonBearArray = {}

	--数字key值数组
	self.key_code = {}
	for i=1,KEY_COUNT do
		self.key_code[i] = tostring(KEY_NUM_START + i - 1)
	end

	--table.getn(self.balloonBearArray)
	for k,v in pairs(self.key_code) do
		self.key_code[v] = k
	end

	self:setKeypadEnabled(true)
	self:addNodeEventListener(cc.KEYPAD_EVENT,handler(self,self.handleKeypad))

	 local scheduler = cc.Director:getInstance():getScheduler()
	 self.schedulerID = scheduler:scheduleScriptFunc(function()
	 	createBalloonBear(ONCE_CREATE_COUNT)
	 end,0,false)  


	function createBalloonBear(count)
		self.balloonbear_count = self.balloonbear_count + count

		for i=1,count do
			local x,y = initStartPosition()
			local balloonbear = BalloonBear.new(self.param);
			--将精灵数据保存到数组中
			self.balloonBearArray[#self.balloonBearArray + 1] = balloonbear

			--开启精灵运动
			balloonbear:pos(x, y)
			:addTo(self)
			:setZOrder(10)
			:runAsTrack("bezier", cc.p(x, y))
		end
		
		if self.balloonbear_count == count then
			cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
	 		self.schedulerID = scheduler:scheduleScriptFunc(function()
	 			createBalloonBear(count)
	 			end,SPRITE_CREATE_INTERVAL,false)  
		end

	end

	--添加返回按钮
	self.backButton = BubbleButton.new({
        image = "common/back2.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
        	--停止播放生成声音
        	stopSpeeking()
        	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
        	if self.schedulerID_2 ~= nil then
           		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID_2)
           		self.schedulerID_2 = nil
           	end
        	if g_selectLevel ~= nil then
        		g_selectLevel:setButtonEnabled(true)
        	end
           	self:removeFromParent()
        end,
    })
    :pos(display.cx * 2 - 70, display.cy * 2 - 40)
    :addTo(self)

	--添加录音按钮
	cc.ui.UIPushButton.new({ normal = "common/record.png", pressed = "common/record_down.png" })
    :onButtonClicked(function()
    	if device.platform == "android" then
    		local javaClassName = "org/cocos2dx/lua/AppActivity"
        	local javaMethodName = "startSpeech"
        	local javaParams = {}
        	local javaMethodSig = "()V"
        	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
    	end

    end)
    :pos(100,  100)
    :addTo(self)

    --弹出游戏结束对话框
    self:popPause(self)


	-- 1.获取事件分发器  : EventDispatcher
    local dispatcher = cc.Director:getInstance():getEventDispatcher()

    -- 2.创建事件监听器  : EventListener 
    local listener1 = cc.EventListenerCustom:create(TAG_BALLOONBEAR_REMOVE, handler(self,self.removeCallBack))

    -- 3.在事件分发器中，添加监听器。事件响应委托为
    dispatcher:addEventListenerWithSceneGraphPriority(listener1, self)


    local listener2 = cc.EventListenerCustom:create(STOP_CREATE_SPRITE, handler(self,self.stopCreateSprite))

    dispatcher:addEventListenerWithSceneGraphPriority(listener2, self)

    -- 语音接收响应
    local listener3 = cc.EventListenerCustom:create(MSG_SPEECH_EVENT, handler(self,self.handerSpeeech))

    dispatcher:addEventListenerWithSceneGraphPriority(listener3, self)

    -- 接受数字点击响应
    local listener4 = cc.EventListenerCustom:create(MSG_CLICK_DIGITAL_EVEN, handler(self,self.handleCustome))

    dispatcher:addEventListenerWithSceneGraphPriority(listener4, self)


    --打开节点进入退出响应
    self:setNodeEventEnabled(true)

    if device.platform == "android"  then
    	-- 将functionId 传给java
		local javaClassName = "org/cocos2dx/lua/Iat"
	    local javaMethodName = "registerLuaCallback"
	    local javaParams = {
	        function(data)
	        	local event = cc.EventCustom:new(MSG_SPEECH_EVENT)
	        	event.userdata = data
	    		dispatcher:dispatchEvent(event) 
	        end
	    }
	    
	    local javaMethodSig = "(I)V"
	    luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
    end 

    
    self.schedulerID_2 = scheduler:scheduleScriptFunc(function()
    	playSound(StoryData["balloon"][1])
		self:stopCreateSprite()
		for i=1,#self.balloonBearArray do
			if self.balloonBearArray[i] ~= nil then
				self.balloonBearArray[i]:removeFromParent()
			end
		end
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID_2)
        self.schedulerID_2 = nil
        local gameOverDlg = GameOverDlg.new()
        :pos(0,0)
        :setZOrder(1000)
        :addTo(self)
    end,120,false)

end

function BalloonBearLayer:handerSpeeech(event)
	local word1 = nil
	local word2 = nil

	-- 判断是否为数字
	for i=1, #digital_array do
		if event.userdata == digital_array[i][1] or event.userdata == digital_array[i][2] then
			word1 = digital_array[i][1]
			word2 = digital_array[i][2]
			break
		end
	end

	-- 判断是否为英文字母
	if word == nil then
		for i=1, #letter_array do
			if event.userdata == letter_array[i][1] or event.userdata == letter_array[i][2] then
				word1 = letter_array[i][1]
				word2 = letter_array[i][2]
				break
			end
		end
	end

	if word1 ~= nil or word2 ~= nil then
		for i=1,#self.balloonBearArray do
			if word1 == self.balloonBearArray[i].flagword or word2 == self.balloonBearArray[i].flagword then
				local balloonBear = self.balloonBearArray[i]
				table.remove(self.balloonBearArray,i)
				self:reorderChild(balloonBear, TAG_MAX_ZORDER)
				balloonBear:decompose()
				--播放鼓励语
				playSound(StoryData["compliments"][1])
				break
			end
		end
	end
end	

function BalloonBearLayer:handleKeypad(event)
	--dump(event)
	if self.key_code[event.key] ~= nil then
		for i=1,#self.balloonBearArray do
			if tostring(self.key_code[event.key] - 1) ==  self.balloonBearArray[i].flagword then
				local balloonBear = self.balloonBearArray[i]
				table.remove(self.balloonBearArray,i)
				self:reorderChild(balloonBear, TAG_MAX_ZORDER)
				balloonBear:decompose()
				playSound(StoryData["compliments"][1])
				break
			end
		end
	end
end

function BalloonBearLayer:handleCustome(event)
	for i=1,#self.balloonBearArray do
		if event.userdata == self.balloonBearArray[i] and event.userdata.flagword == self.balloonBearArray[i].flagword then
			local balloonBear = self.balloonBearArray[i]
			table.remove(self.balloonBearArray,i)
			self:reorderChild(balloonBear, TAG_MAX_ZORDER)
			balloonBear:decompose()
			break
		end
	end
end	

function BalloonBearLayer:decompose(balloonbear)

	--弹出数字
	local wordSprite =  display.newSprite(balloonbear.sword_name)
	:setScale(0.3)
	:pos(display.cx, display.cy)
	:addTo(self)
	:scaleTo(1.0, 2.5)

	local scheduler = cc.Director:getInstance():getScheduler()
	local schedulerID = nil  
	schedulerID = scheduler:scheduleScriptFunc(function()
	 	wordSprite:removeSelf()
	 	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(schedulerID)
	end,1.0,false)

	--小熊掉下被拯救
	local position = balloonbear:getPosition()

end


--精灵被删除回调
function BalloonBearLayer:removeCallBack(event)

	for i=1,#self.balloonBearArray do
		if self.balloonBearArray[i].flagword == event.userdata.flagword then
			table.remove(self.balloonBearArray,i)
			break
		end	
	end

	event.userdata:removeSelf()
	--dump(event)
end

--停止精灵创建
function BalloonBearLayer:stopCreateSprite()
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
	local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(self
    	)
    self.gamefinish = true
end

--移动云彩
function BalloonBearLayer:moveCloud(px,py,t)
	if self.gamefinish == false then
		local cloud = display.newSprite("common/cloud.png")
	    :pos(px, py)
	    :setZOrder(2)
	    :addTo(self)

	    transition.moveTo(cloud, {
	        x = display.cx * 2 + 100,
	        y = py,
	        time = t,
	        onComplete = function ()
	            if self ~= nil then
	                cloud:removeFromParent()
	                self:moveCloud(px,py,t)
	            end 
	        end,})
	end
end

function BalloonBearLayer:popPause(target)
    local scheduler = cc.Director:getInstance():getScheduler()
	local schedulerID = nil  
	schedulerID = scheduler:scheduleScriptFunc(function()
			target:removeAllChildren()
			target:stopCreateSprite()
			cc.Director:getInstance():getScheduler():unscheduleScriptEntry(schedulerID)
		    local gameOverDlg = require("app.balloon.GameOverDlg").new()
		    :setZOrder(1000)
		    :addTo(target)

		    --cc.Director:getInstance():pause()
	end,120,false) 
end

function BalloonBearLayer:onEnter()

end

function BalloonBearLayer:onExit()
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID_2)
	local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(self)
end

return BalloonBearLayer

