--消息标识
TAG_BALLOONBEAR_REMOVE = "kBalloonBearRemove"

STOP_CREATE_SPRITE = "msg_stop_create_sprite"

CREATE_A_NEW_LEVEL = "msg_create_a_new_level"

MSG_CLICK_DIGITAL_EVEN = "msg_click_digital_event"

--最高移动位置
HIGHEST_MOVE_Y = display.cy * 2 - 50


--颜色
color_array = {
	"红色",
	"蓝色",
	"绿色",
	"紫色",
	"黄色",
	"白色",
	"黑色"
}

digital_array = {
	{"0","零"},
	{"1","一"},
	{"2","二"},
	{"3","三"},
	{"4","四"},
	{"5","五"},
	{"6","六"},
	{"7","七"},
	{"8","八"},
	{"9","九"}
}

letter_array = {
	{"A","a"},{"B","b"},
	{"C","c"},{"D","d"},
	{"E","e"},{"F","f"},
	{"G","g"},{"H","h"},
	{"I","i"},{"J","j"},
	{"K","k"},{"L","l"},
	{"M","m"},{"N","n"},
	{"O","o"},{"P","p"},
	{"Q","q"},{"R","r"},
	{"S","s"},{"T","t"},
	{"U","u"},{"V","v"},
	{"W","w"},{"X","x"},
	{"Y","y"},{"Z","z"}
}

flagword_array = {
	"0","1","2","3","4","5","6","7","8","9",
	"零","一","二","三","四","五","六","七","八","九",
	"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
	"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"
}

--运动轨迹bezier控制点
function BEZIER_CONTROL_POINT(position)
	return cc.p(math.random(50,display.cx * 2 - 50),display.cy + math.random(-50,50))
end	

--运动轨迹bezier结束点
function BEZIER_END_POINT(position)
	return cc.p(position.x, 700)
end

--精灵随机起始点
function initStartPosition()
	local x = math.random(100,display.cx * 2 - 100)
	local y = -150
	return x,y
end

--精灵的最大Zoder
TAG_MAX_ZORDER = 80

--精灵动作标签
TAG_BALLOONBEAR_ACTION = 1111

--精灵做bezier运动时间
MOVING_TIME = 25

--精灵创建的间隔时间
SPRITE_CREATE_INTERVAL = 10

--键值个数
KEY_COUNT = 10

--数字起始键值
KEY_NUM_START = 76

--每次创建的个数
ONCE_CREATE_COUNT = 1

--关卡总数
LEVEL_COUNT = 3


