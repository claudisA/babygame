require("app.balloon.data")
require("app.luaCallJava")

Cloud = class("Cloud", function()
    return display.newSprite()
end)

function Cloud:ctor(_digital)
	self.digital = _digital

	--self.sCloud = display.newSprite("common/cloud.png")
	--:addTo(self)

	self.sCloud = cc.ui.UIPushButton.new({ normal = "common/cloud.png", pressed = "common/cloud.png" })
    :onButtonClicked(function()
		playSound(tostring(self.digital))
		local event = cc.EventCustom:new(MSG_CLICK_DIGITAL_EVEN)
		event.userdata = self
		-- 1.获取事件分发器  : EventDispatcher
		local dispatcher = cc.Director:getInstance():getEventDispatcher()
		dispatcher:dispatchEvent(event)
    end)
    :addTo(self)


	self.digitallabel = CCLabelAtlas:_create(""..self.digital,"common/digital.png",76,115,string.byte('0'))
	:setAnchorPoint(0.5,0.5)
	:setScale(0.6)
	:addTo(self)
end

function Cloud:decompose()
	self.digitallabel:removeFromParent()

	local x = self:getPositionX()
    local y = self:getPositionY()
	label = CCLabelAtlas:_create(""..self.digital,"common/digital.png",76,115,string.byte('0'))
	:setAnchorPoint(0.5,0.5)
	:pos(x, y)
	:setScale(0.6)
	:addTo(self:getParent());

	local node_point =  cc.p(display.cx, display.cy)
	local action1 = CCJumpTo:create(0.6,cc.p(node_point.x,node_point.y),30, 2)
	local action2 = CCScaleTo:create(0.6, 2.5)
	local sequence = cc.Sequence:create(
		action1,
		action2,
		cc.DelayTime:create(0.3),
		cc.CallFunc:create(handler(self, function ()
			label:removeFromParent()
		end)),
		nil)  
	label:runAction(sequence)
end	

return Cloud