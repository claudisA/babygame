local BubbleButton = import("app.common.BubbleButton")

Digital = class("Digital", function()
    return display.Layer()
end)

function Digital:ctor(_digital)
	self.digital = _digital
end


return Digital
