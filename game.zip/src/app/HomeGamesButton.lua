HomeGamesButton = class("HomeGamesButton", function()
    return display.newSprite()
end)

local BubbleButton = import("app.common.BubbleButton")

function HomeGamesButton:ctor(strImg,strTitle,listenerFuc)
	self.button = BubbleButton.new({
	    image = strImg,
	    sound = nil,
	    prepare = function()
	        --audio.playSound(GAME_SFX.tapButton)
	        self.button:setButtonEnabled(false)
	    end,
	    listener = listenerFuc,
  	})
  	:addTo(self)

	display.newSprite(strTitle)
	:pos(0, -100)
	:addTo(self)
end

function HomeGamesButton:setButtonEnabled(able)
	self.button:setButtonEnabled(able)
end

return HomeGamesButton
