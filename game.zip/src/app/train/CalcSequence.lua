CalcSequence = class("CalcSequence", function()
    return display.newSprite()
end)

function CalcSequence:ctor(seq)
	local bg = display.newSprite("train/circle_point.png")
	:pos(0 + (seq[#seq] - 1) * 20, 0)
	:addTo(self)

	for i=1,#seq - 1 do
		--×
		local str = tostring(seq[i])
		if str == "*" then
			str = "×"
		end
		if str == "/" then
			str = "÷"
		end

		cc.ui.UILabel.new({UILabelType = 2, text = str, size = 20,color = cc.c3b(0,0,255)})
	    :align(display.CENTER,0 + (i - 1) * 20, 0)
	    :addTo(self)
	end

end

return CalcSequence