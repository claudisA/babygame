require("app.train.Locomotive")
require("app.train.Vagon")

Train = class("Train", function()
    return display.newSprite()
end)

local VAGON_WIDTH = 120

function Train:ctor(nums,hideidx)
	self.hideidx = hideidx
	self.locomotive = Locomotive.new()
	:addTo(self)

	local size = self.locomotive.head:getContentSize()

	self.vagon = {}
	for i=1,#nums do
		self.vagon[#self.vagon + 1] = Vagon.new(nums[i])
		:pos(size.width / 2 + (i - 1) * VAGON_WIDTH + VAGON_WIDTH / 2, -20)
		:addTo(self)
	end
end

function Train:getTrainLength()
	local size1 = self.locomotive.head:getContentSize()
	local size2 = self.vagon[1].carriage:getContentSize()
	return size1.width + #self.vagon * size2.width
end

function Train:run()
	self.locomotive:run()
	for i=1,#self.vagon do
		self.vagon[i]:run()
	end
end

function Train:stop()
	self.locomotive:stop()
	for i=1,#self.vagon do
		self.vagon[i]:stop()
	end
end

function Train:addVagon()
	-- body
end

function Train:playVagonAction()
	for i=1,#self.vagon do
		if self.hideidx ~= i then
			self.vagon[i]:playAction()
		end
	end

	self.vagon[self.hideidx]:palyQuestionMarkAction()
end

function Train:detectMoveIn(point,param)
	for i=1,#self.vagon do
		local isIn,right = self.vagon[i]:detectMoveIn(point,param)
		if isIn == true and right == true then
			return true
		end
	end
	return false
end

function Train:getQustVagonPosition()
	local point = self.vagon[self.hideidx].question_mark:convertToWorldSpace(cc.p(0,0))
	return point.x,point.y
end

return Train