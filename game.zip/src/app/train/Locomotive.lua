Locomotive = class("Locomotive", function()
    return display.newSprite()
end)

function Locomotive:ctor()
	self.head = display.newSprite("train/Locomotive/loko.png")
	:addTo(self)

	--小轮子
	self.little_wheel = nil
	--大轮子
	self.big_wheel = nil

	local little_wheel = display.newSprite("train/Locomotive/lokoKolo1_1.png")
  	:pos(-48,-50)
  	:addTo(self)

  	local big_wheel = display.newSprite("train/Locomotive/lokoKolo2_1.png")
  	:pos(-1,-45)
  	:addTo(self)

  	--self:run()
end

function Locomotive:run()
	  display.addSpriteFrames("train/Locomotive/little_wheel.plist", "train/Locomotive/little_wheel.png") 
  	self.little_wheel = display.newSprite()
  	:pos(-48,-50)
  	:addTo(self)
  	local frames1 = display.newFrames("lokoKolo1_%d.png", 1, 4)
  	local animation1 = display.newAnimation(frames1, 2.8/14.0)
  	self.little_wheel:playAnimationForever(animation1)

  	display.addSpriteFrames("train/Locomotive/big_wheel.plist", "train/Locomotive/big_wheel.png") 
  	self.big_wheel = display.newSprite()
  	:pos(-1,-45)
  	:addTo(self)
  	local frames2 = display.newFrames("lokoKolo2_%d.png", 1, 4)
  	local animation2 = display.newAnimation(frames2, 2.8/14.0)
  	self.big_wheel:playAnimationForever(animation2)

  	--蒸汽
  	display.addSpriteFrames("train/lokoKour/lokoKour.plist","train/lokoKour/lokoKour.png")
  	self.kour =  display.newSprite()
  	:pos(20,110)
  	:addTo(self)
  	local framesKour = display.newFrames("lokoKour%d.png", 1, 9)
  	local animationKour = display.newAnimation(framesKour, 2.8/14.0)
  	self.kour:playAnimationForever(animationKour)
end

function Locomotive:stop()
	self.little_wheel:removeFromParent()
	self.big_wheel:removeFromParent()
	self.kour:removeFromParent()
end

return Locomotive