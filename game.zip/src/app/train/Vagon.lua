Vagon = class("Vagon", function()
    return display.newSprite()
end)

function Vagon:ctor(param)
	self.question_mark = display.newSprite("train/question_mark.png")
	:pos(0,0)
	:addTo(self)
	self.question_mark:setVisible(false)

	self.param = param
	if type(param) == "number" then
		self.calcNode = CCLabelAtlas:_create(""..param,"common/digital.png",76,115,string.byte('0'))
		:setAnchorPoint(0.5,0.5)
		:setScale(0.6)
		:addTo(self)
	end

	if type(param) == "string" then
		if param == "+" then
			self.calcNode = display.newSprite("common/symbols+.png")
		elseif param == "-" then
			self.calcNode = display.newSprite("common/symbols-.png")
		elseif param == "*" then
			self.calcNode = display.newSprite("common/symbols_.png")
		elseif param == "/" then
			self.calcNode = display.newSprite("common/symbols_div.png")
		elseif param == "=" then
			self.calcNode = display.newSprite("common/symbols=.png")
		end
		self.calcNode
		:setScale(0.6)
		:addTo(self)
	end

	self.calcNode:setVisible(false)

	local size = self.calcNode:getContentSize()
    size.width = size.width * 0.6
    size.height = size.height * 0.6
	self.kuang_rect = {-size.width / 2,size.width / 2,80 - size.height / 2,80 + size.height}


	local idx = math.random(1,5)
	self.carriage = display.newSprite(string.format("train/vagon/vagon%d.png",idx))
	:addTo(self)

	local wheel1 = display.newSprite("train/vagon/vagonKolo1.png")
  	:pos(-28,-36)
  	:addTo(self)

  	local wheel2 = display.newSprite("train/vagon/vagonKolo1.png")
  	:pos(4,-36)
  	:addTo(self)

  	local wheel3 = display.newSprite("train/vagon/vagonKolo1.png")
  	:pos(36,-36)
  	:addTo(self)

  	--self:run()
end

function Vagon:run()
	display.addSpriteFrames("train/vagon/vagonKolo.plist", "train/vagon/vagonKolo.png") 
  	
  	self.wheel1 = display.newSprite()
  	:pos(-28,-36)
  	:addTo(self)
  	local frames1 = display.newFrames("vagonKolo%d.png", 1, 8)
  	local animation1 = display.newAnimation(frames1, 2.8/14.0)
  	self.wheel1:playAnimationForever(animation1)

  	self.wheel2 = display.newSprite()
  	:pos(4,-36)
  	:addTo(self)
  	local frames2 = display.newFrames("vagonKolo%d.png", 1, 8)
  	local animation2 = display.newAnimation(frames2, 2.8/14.0)
  	self.wheel2:playAnimationForever(animation2)

  	self.wheel3 = display.newSprite()
  	:pos(36,-36)
  	:addTo(self)
  	local wheel3 = display.newFrames("vagonKolo%d.png", 1, 8)
  	local animation3 = display.newAnimation(wheel3, 2.8/14.0)
  	self.wheel3:playAnimationForever(animation3)
end

function Vagon:stop()
	self.wheel1:removeFromParent()
	self.wheel2:removeFromParent()
	self.wheel3:removeFromParent()
end

function Vagon:playAction()
	self.calcNode:setVisible(true)
	transition.moveTo(self.calcNode, {
		y = 80,
		time = 1,
		onComplete = function ()

		end,})
end

function Vagon:palyQuestionMarkAction()
	self.question_mark:setVisible(true)
	transition.moveTo(self.question_mark, {
		y = 80,
		time = 1,
		onComplete = function ()
			local act1 = CCMoveBy:create(0.5,cc.p(0,10))
			local act2 = CCMoveBy:create(0.5,cc.p(0,-10))
			local act = cc.Sequence:create(act1,act2)
			self.question_mark:runAction(cc.RepeatForever:create(act))
		end,})
end

function Vagon:detectMoveIn(point,param)
	local p = self:convertToNodeSpaceAR(point)
	if p.x > self.kuang_rect[1] and p.x < self.kuang_rect[3] and p.y > self.kuang_rect[2] and p.y < self.kuang_rect[4] then
		if self.calcNode:isVisible() == false and self.param == param then
			self.question_mark:removeFromParent()
			self.calcNode:pos(0,80)
			self.calcNode:setVisible(true)
			return true,true
		else
			return true,false
		end
	else
		if self.param == param then
			return false,true
		else
			return false,false
		end
	end

end

return Vagon