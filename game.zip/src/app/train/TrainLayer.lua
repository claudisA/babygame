require("app.train.Locomotive")
require("app.train.Vagon")
require("app.train.Train")
require("app.train.TrainGameOverDlg")
require("app.GlobalData")
require("app.luaCallJava")

local BubbleButton = import("app.common.BubbleButton")

TrainLayer = class("TrainLayer", function()
    return display.newLayer()
end)

local COL = 3
local ROW = 6
local startx = 0
local dx = (display.cx * 2 - 160) / ROW 
local starty = display.cy - 50
local dy = display.cy / COL
local rand_select_count = 5
local value_count = rand_select_count + 4 + 1
local tips_count = 3

local symbol = {
	"+",
	"-",
	"*",
	"/"
}

function TrainLayer:ctor()
	self.modname = "app.train.TrainLayer"

	self.rightValue = nil
	self.movetimes = 0
	self.finger = nil
	self.hideidx = nil
	self.valueNodes = {}
	self.selectSprite = nil
	self.startPoint = {}
	self.moveValue = nil
	self.isOk = false
	self.calcSequence = {}
	self.rigthCalcSequenceArr = {}
	local bg = display.newSprite("train/hraPozadi.png")
	:pos(display.cx, display.cy)

	local size = bg:getContentSize()
	bg:setScale(display.cx * 2 / size.width, display.cy * 2 / size.height)
	bg:addTo(self)

	self.circlebg = display.newSprite("bird/circle_bg.png")
	:pos(display.cx, display.cy)
	:setVisible(false)
	:addTo(self)

	self:createATrain()

	--添加返回按钮
	self.backButton = BubbleButton.new({
        image = "common/back2.png",
        sound = nil,
        prepare = function()
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
           	--停止播放生成声音
        	stopSpeeking()
        	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
        	if g_selectLevel ~= nil then
        		g_selectLevel:setButtonEnabled(true)
        	end
           	self:removeFromParent()
        end,
    })
    :pos(display.cx * 2 - 70, display.cy * 2 - 40)
    :addTo(self)

	self:addNodeEventListener(cc.NODE_TOUCH_EVENT,function(event)
        if event.name == "began" then

            if self:onTouchBegan(cc.p(event.x,event.y)) then
                return true
            end
            return false

        elseif event.name == "moved" then
            self:onTouchMoved(cc.p(event.x,event.y))
        elseif event.name == "ended" then
            self:onTouchEnded(cc.p(event.x,event.y))
        end
    end)
	self:setTouchSwallowEnabled(false) 

	local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerID = nil  
    self.schedulerID = scheduler:scheduleScriptFunc(function()
		   	for i=1,value_count do
				if self.valueNodes[i] ~= nil then
					self.valueNodes[i]:removeFromParent()
				end
			end
			if #self.rigthCalcSequenceArr >= 3 then
				playSound(string.format(StoryData["train"][4],#self.rigthCalcSequenceArr))
			else
				playSound(string.format(StoryData["train"][5],#self.rigthCalcSequenceArr))
			end
			
			self.train:removeFromParent()
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
            local trainGameOverDlg = TrainGameOverDlg.new(self.rigthCalcSequenceArr)
            :pos(display.cx,display.cy)
            :setZOrder(1000)
            :addTo(self)
    end,120,false)

    --打开节点进入退出响应
    self:setNodeEventEnabled(true)
end

function TrainLayer:onTouchBegan(point)
	return true
end

function TrainLayer:onTouchMoved(point)
end

function TrainLayer:onTouchEnded(point)
	if  self.selectSprite ~= nil then
		if self.train:detectMoveIn(point,self.moveValue) == true then
			audio.playSound("sound/win.wav")
			if self.finger ~= nil then
				self.finger:removeFromParent()
				self.finger = nil
			end
			for i=1,#self.valueNodes do
				self.valueNodes[i]:setTouchEnabled(false)
				if self.valueNodes[i] == self.selectSprite then
					self.valueNodes[i] = nil
					break
				end
			end
			self.selectSprite:removeFromParent()
			self.selectSprite = nil
			self:displayRightPaticle()
			self:removeNodes()
			self.rigthCalcSequenceArr[#self.rigthCalcSequenceArr + 1] = {}
			for i=1,#self.calcSequence do
				self.rigthCalcSequenceArr[#self.rigthCalcSequenceArr][i] = self.calcSequence[i]
			end
			self.rigthCalcSequenceArr[#self.rigthCalcSequenceArr][#self.calcSequence + 1] = self.hideidx

		else
			self.movetimes = self.movetimes + 1
			if self.movetimes == 3 then 
				if self.finger ~= nil then
					self.finger:removeFromParent()
					self.finger = nil
				end
				playSound(string.format(StoryData["train"][3],self.rightValue))

				local x = self.rightLable:getPositionX()
		 		local y = self.rightLable:getPositionY()
				self.circlebg:pos(x,y)
				:setVisible(true)
				local act1 = CCTintTo:create(0.1, 255 * 1/3, 255 * 1/3, 255 * 1/3);
				local act2 = CCTintTo:create(0.1, 255, 255, 255);
				local sequence = cc.Sequence:create(act1,act2,nil)
				self.circlebg:runAction(CCRepeatForever:create(sequence))

				local sequence = cc.Sequence:create(
				cc.DelayTime:create(2.0),
				cc.CallFunc:create(handler(self, function ()
					self.circlebg:setVisible(false)
					self.train:removeFromParent()
					self:createATrain()
				end)),
				nil)  
				self:runAction(sequence)
			else
				playSound(StoryData["train"][2]) 
			end
			
		 	self.selectSprite:pos(self.startPoint[1],self.startPoint[2])
		 	self.selectSprite = nil

		end
	end
end

function TrainLayer:createCalcSeq()
	local num1 = math.random(1,10);
	local num2 = math.random(1,10);
	local num1 = math.random(1,10);
	local result = nil

	local find = false
    local index = nil
	while find == false do
		index = math.random(1,4);
		if index == 1 then
			result = num1 + num2
			find = true
		elseif index == 2 then
		    if num1 >= num2 then
		    	result = num1 - num2
		    	find = true
		    end
		elseif index == 3 then
		    result = num1 * num2
		    find = true
		elseif index == 4 then
		    if num1 % num2 == 0 then
		    	result = num1 / num2
		    	find = true
		    end
		end
	end

	self.calcSequence[1] = num1
	self.calcSequence[2] = symbol[index]
	self.calcSequence[3] = num2
	self.calcSequence[4] = "="
	self.calcSequence[5] = result
end

function TrainLayer:getHideIdx()
	local idx = math.random(1,5);
	while idx == 4 do
		idx = math.random(1,5)
	end
	return idx
end

function TrainLayer:getColRowAngle()
	local row = math.random(1,ROW)
	local col = math.random(1,COL)
	local num = math.random(1,100)
	local angle = math.random(-50,50)
	while self.squreMatrix[col][row] == 1 do
		col = math.random(1,COL)
		row = math.random(1,ROW)
	end
	self.squreMatrix[col][row] = 1
	return col,row,angle
end

function TrainLayer:displayRightPaticle()
	local points = {}
	for i=1,6 do
		x = math.random(display.cx - 200,display.cy + 200)
		y = math.random(display.cy - 100,display.cy + 300)
		points[i] = {x,y}
	end

	for i=1,#points do
		local sequence = cc.Sequence:create(
			cc.DelayTime:create(0.5 * i),
			cc.CallFunc:create(handler(self, function ()
				audio.playSound("sound/particle_sfx.mp3")
				local particle = cc.ParticleSystemQuad:create("particles/puff_candy.plist")
				:pos(points[i][1],points[i][2])
				:setZOrder(1000)
				:addTo(self)
			end)),
			nil)  
		self:runAction(sequence)
	end
end

function TrainLayer:removeNodes()
	self.train:run()
	local sequence = cc.Sequence:create(
			cc.DelayTime:create(0.5 * (7 + 1)),
			cc.CallFunc:create(handler(self, function ()
				transition.moveTo(self.train, {
					x = -display.cx * 2,
					time = 3,
					onComplete = function ()
						self.train:stop()
						self.train:removeFromParent()
						self:createATrain()
					end,})
			end)),
			nil)  
	self:runAction(sequence)

	for i=1,value_count do
		if self.valueNodes[i] ~= nil then
			self.valueNodes[i]:runAction(CCFadeOut:create(4))
		end
	end
end

function TrainLayer:createATrain()
	for i=1,value_count do
		if self.valueNodes[i] ~= nil then
			self.valueNodes[i]:removeFromParent()
		end
	end
	self.valueNodes = {}

	self.squreMatrix = {}
	for i=1,COL do
		self.squreMatrix[i] = {}
		for j=1,ROW do
			self.squreMatrix[i][j] = 0
		end
	end

	self:createCalcSeq()
	self.hideidx = self:getHideIdx()

	--创建正确答案
	local col,row,angle = self:getColRowAngle()
	local value = self.calcSequence[self.hideidx]
	if value ~= "+" and value ~= "-" and value ~= "*" and value ~= "/" and value ~= "=" then
		self.rightValue = value
		self.rightLable = CCLabelAtlas:_create(""..value,"common/digital.png",76,115,string.byte('0'))
		:setAnchorPoint(0.5,0.5)
		:pos(startx + dx * row, starty + dy * col)
		:setScale(0.6)
		:setRotation(angle)
		:setOpacity(10)
		:setZOrder(10)
		:addTo(self)
		self.valueNodes[#self.valueNodes + 1] = self.rightLable
		self.rightLable:runAction(CCFadeIn:create(4))

		self.rightLable:setTouchEnabled(true)
		self.rightLable:setTouchSwallowEnabled(false) 
		self.rightLable:setTouchMode(cc.TOUCHES_ALL_AT_ONCE)        
		self.rightLable:addNodeEventListener(cc.NODE_TOUCH_EVENT,function(event)
		 		if event.name == "began" then
		 			self.startPoint[1] = self.rightLable:getPositionX()
		 			self.startPoint[2] = self.rightLable:getPositionY()
		 			self.selectSprite = self.rightLable
		 			self.moveValue = value
		        elseif event.name == "added" then
		        elseif event.name == "moved" then
		        	self.rightLable:pos(event.points["0"]["x"],event.points["0"]["y"])
		        elseif event.name == "removed" then
		        elseif event.name == "ended" then
		        end 
		    	return true	
			end)
    end

    --创建+-*/
	for i=1,4 do
		local col,row,angle = self:getColRowAngle()
		local symbolSprite = nil
		if i == 1 then
			symbolSprite = display.newSprite("common/symbols+.png")
			if value == "+" then
				self.rightLable = symbolSprite
			end
		elseif i == 2 then
			symbolSprite = display.newSprite("common/symbols-.png")
			if value == "-" then
				self.rightLable = symbolSprite
			end
		elseif i == 3 then
			symbolSprite = display.newSprite("common/symbols_.png")
			if value == "*" then
				self.rightLable = symbolSprite
			end
		elseif i == 4 then
			symbolSprite = display.newSprite("common/symbols_div.png")
			if value == "/" then
				self.rightLable = symbolSprite
			end
		end
		symbolSprite:pos(startx + dx * row, starty + dy * col)
		:setScale(0.6)
		:setOpacity(10)
		:setZOrder(10)
		:addTo(self)



		self.valueNodes[#self.valueNodes + 1] = symbolSprite
		symbolSprite:runAction(CCFadeIn:create(4))

		symbolSprite:setTouchEnabled(true)
		symbolSprite:setTouchSwallowEnabled(false) 
		symbolSprite:setTouchMode(cc.TOUCHES_ALL_AT_ONCE)        
		symbolSprite:addNodeEventListener(cc.NODE_TOUCH_EVENT,function(event)
		 		if event.name == "began" then
		 			self.startPoint[1] = symbolSprite:getPositionX()
		 			self.startPoint[2] = symbolSprite:getPositionY()
		 			self.selectSprite = symbolSprite
		 			self.moveValue = symbol[i]
		        elseif event.name == "added" then
		        elseif event.name == "moved" then
		        	symbolSprite:pos(event.points["0"]["x"],event.points["0"]["y"])
		        elseif event.name == "removed" then
		        elseif event.name == "ended" then
		        end 
		    	return true	
			end)
	end

    self.train = Train.new(self.calcSequence,self.hideidx)
	:addTo(self)
	self.train:pos(display.cx * 2,155) 
	self.train:run()
	transition.moveTo(self.train, {
		x = 100,
		y = 155,
		time = 2.5,
		onComplete = function ()
			self.train:stop()
			self.train:playVagonAction()
			if tips_count > 0 then
				playSound(StoryData["train"][1])
				tips_count = tips_count - 1
			end
			
			local sequence = cc.Sequence:create(
			cc.DelayTime:create(1.0),
			cc.CallFunc:create(handler(self, function ()
				if tips_count > 0 then
					self:playTips()
				end
				self.movetimes = 0
			end)),
			nil) 
			self:runAction(sequence) 
		end,})

	for i=1,rand_select_count do
		local col,row,angle = self:getColRowAngle()
		local num = math.random(1,100)
		local lable = CCLabelAtlas:_create(""..num,"common/digital.png",76,115,string.byte('0'))
		:setAnchorPoint(0.5,0.5)
		:pos(startx + dx * row, starty + dy * col)
		:setScale(0.6)
		:setRotation(angle)
		:setOpacity(10)
		:setZOrder(10)
		:addTo(self)
		self.valueNodes[#self.valueNodes + 1] = lable
		lable:runAction(CCFadeIn:create(4))

		lable:setTouchEnabled(true)
		lable:setTouchSwallowEnabled(false) 
		lable:setTouchMode(cc.TOUCHES_ALL_AT_ONCE)        
		lable:addNodeEventListener(cc.NODE_TOUCH_EVENT,function(event)
		 		if event.name == "began" then
		 			self.startPoint[1] = lable:getPositionX()
		 			self.startPoint[2] = lable:getPositionY()
		 			self.selectSprite = lable
		 			self.moveValue = num
		        elseif event.name == "added" then
		        elseif event.name == "moved" then
		        	lable:pos(event.points["0"]["x"],event.points["0"]["y"])
		        elseif event.name == "removed" then
		        elseif event.name == "ended" then
		        end 
		    	return true	
			end)
	end
end

function TrainLayer:playTips()
	local x = self.rightLable:getPositionX() + 60
	local y = self.rightLable:getPositionY() - 60
	
	if self.finger == nil then
		self.finger = display.newSprite("train/finer.png")
		:pos(x,y)
		:setZOrder(20)
		:addTo(self)
	end

	local endx,endy = self.train:getQustVagonPosition()
	endx = endx + 80
	endy = endy

	transition.moveTo(self.finger, {
	 	x = endx,
	 	y = endy,
	 	time = 3,
	 	onComplete = function ()
	 		self.finger:pos(x,y)
	 		self:playTips()
	 	end,
	 	})	
end

function TrainLayer:onEnter()

end

function TrainLayer:onExit()
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
end	

return TrainLayer
