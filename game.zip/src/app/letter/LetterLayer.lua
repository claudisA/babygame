require("app.letter.Word")
require("app.utils.luaUtils")
require("app.letter.LetterGameOverDlg")
require("app.GlobalData")

local wordsData = nil

function loadWordsData()
	if wordsData == nil then
		wordsData = json.decode(cc.HelperFunc:getFileData("letters/words.json"))
	end
end

loadWordsData()

local BubbleButton = import("app.common.BubbleButton")

LetterLayer = class("LetterLayer", function()
    return display.newLayer()
end)

function LetterLayer:ctor()
	self.modname = "app.letter.LetterLayer"

	local bg = display.newSprite("letters/bg.jpg")
	:pos(display.cx, display.cy)

	local size = bg:getContentSize()
	bg:setScale(display.cx * 2 / size.width, display.cy * 2 / size.height)
	bg:addTo(self)

	self.wordsArray = {}
	self.wordsIdx = PlayerData.wordArrayStartIdx

 	local s = wordsData["studys_words_array"][self.wordsIdx]["en"]
 	self.wordsIdx = self.wordsIdx + 1
	self.word = Word.new(s,{})
	:pos(display.cx,display.cy)
	:addTo(self)

	--添加返回按钮
	self.backButton = BubbleButton.new({
        image = "common/back2.png",
        sound = nil,
        prepare = function()
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
        	--停止播放生成声音
        	stopSpeeking()
        	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
        	if g_selectLevel ~= nil then
        		g_selectLevel:setButtonEnabled(true)
        	end
           	self:removeFromParent()
        end,
    })
    :setLocalZOrder(500)
    :pos(display.cx * 2 - 70, display.cy * 2 - 40)
    :addTo(self)


    local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerID = nil  
    self.schedulerID = scheduler:scheduleScriptFunc(function()
	   	self.word:removeFromParent()
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
        local LetterGameOverDlg = LetterGameOverDlg.new(self.wordsArray)
        :pos(display.cx,display.cy)
        :setZOrder(1000)
        :addTo(self)
    end,120,false)

	-- 1.获取事件分发器  : EventDispatcher
    local dispatcher = cc.Director:getInstance():getEventDispatcher()
    -- 接受数字点击响应
    local listener = cc.EventListenerCustom:create(CREATE_WORD_SPRITE, handler(self,self.createNewWords))
    dispatcher:addEventListenerWithSceneGraphPriority(listener, self)

    --打开节点进入退出响应
    self:setNodeEventEnabled(true)

	self:loadResource()

	audio.playMusic("letters/sound/bg_music.mp3")
end

function LetterLayer:loadResource()
	for i=1,#letters do
		local plist = string.format("letters/lower_animation/%s.plist",letters[i])
		local png = string.format("letters/lower_animation/%s.png",letters[i])
		 display.addSpriteFrames(plist, png)
	end
end

function LetterLayer:createNewWords(event)
	if self.wordsIdx == #wordsData["studys_words_array"] then
		self.wordsIdx = 1
	end
	local s = wordsData["studys_words_array"][self.wordsIdx]["en"]
	self.wordsIdx = self.wordsIdx + 1
	self.word:removeFromParent()
	self.word = Word.new(s,{})
	:pos(display.cx,display.cy)
	:addTo(self)
end

function LetterLayer:onEnter()

end

function LetterLayer:onExit()
	local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(self)
   	audio.stopMusic(false)
end	


return LetterLayer
