require("app.GlobalData")
require("app.luaCallJava")
require("app.utils.luaUtils")

local BubbleButton = import("app.common.BubbleButton")

LetterGameOverDlg = class("LetterGameOverDlg", function()
    return display.newSprite()
end)

function LetterGameOverDlg:ctor(array)
	marklayer = cc.LayerColor:create(cc.c4b(0,0,0,220))
	:pos(-display.cx,-display.cy)
	:addTo(self)

	--播放粒子效果
	local particle1 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx * 2 / 3 * 1 - display.cx,display.cy - 100)
	:addTo(self)

	local particle2 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx * 2 / 3 * 2 - display.cx,display.cy - 100)
	:addTo(self)

	self.panel = display.newSprite("common/panel.png")
	:setScale(2.0)
	:addTo(self)

	local size = self.panel:getContentSize()
	size.width = size.width * 2.0
	size.height = size.height * 2.0

    cc.ui.UILabel.new({
        UILabelType = 2, text = "游戏结束", size = 34,color = cc.c3b(255,0,0)})
    :align(display.CENTER, 0, size.height / 2 - 30)
    :addTo(self)

    if #array < 3 then
    	playSound(string.format(StoryData["letter"][3],#array))
    else
    	playSound(string.format(StoryData["letter"][4],#array))
    end

    local str = "这次回答正确的数字分别是："
    cc.ui.UILabel.new({
    UILabelType = 2, text = str, size = 20,color = cc.c3b(0,255,0)})
    :align(display.CENTER, -size.width / 2 + 150, size.height / 2 - 80)
    :addTo(self)

    for i=1,#array do
    	local y = (getIntPart((i - 1)/ 5)) * (-30)
    	cc.ui.UILabel.new({
            UILabelType = 2, text = array[i], size = 30,color = cc.c3b(0,0,255)})
        :align(display.CENTER, -250 + (i - 1 - (getIntPart((i - 1) / 5) * 5))*120,y)
        :addTo(self)
    end

    self.continueButton = BubbleButton.new({
        image = "common/continue.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.continueButton:setButtonEnabled(false)
        end,
        listener = function()
            if g_mainScene ~= nil then

                local layer = self:getParent()
                if layer.param ~= nil then
                    local newLayer = require(self:getParent().modname).new(layer.param)
                    :addTo(g_mainScene)
                else
                    local newLayer = require(self:getParent().modname).new()
                    :addTo(g_mainScene)
                end
                
                layer:removeFromParent()
            end
        end,
    })
    :pos(-200, -size.height / 2)
    :addTo(self)

	self.backButton = BubbleButton.new({
        image = "common/back.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
            local parent = self:getParent() 
            --停止播放生成声音
            stopSpeeking()
            if g_selectLevel ~= nil then
                g_selectLevel:setButtonEnabled(true)
            end
            parent:removeFromParent()
        end,
    })
    :pos(200, -size.height / 2)
    :addTo(self)

end


return LetterGameOverDlg
