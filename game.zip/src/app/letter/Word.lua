require("app.luaCallJava")
require("app.GlobalData")

Word = class("Word", function()
    return display.newSprite()
end)

letters = {
	"a","b","c","d","e","f","g","h","i","j","k","l","m",
	"n","o","p","q","r","s","t","u","v","w","x","y","z"
}

CREATE_WORD_SPRITE = "msg_create_word_sprite"

local COL = 4
local ROW = 5
local startx = -display.cx + 100
local dx = (display.cx * 2 - 200) / (ROW - 1)
local starty = display.cy - 50
local dy = (-display.cy * 2 + 100) / (COL - 1)

for i,v in ipairs(letters) do
	letters[v] = i
end

function Word:ctor(str,greyIdxs)
	self.words = str
	self.tempSprite = nil
	self.lowSpriteArray = {}
	self.blankSpriteArray = {}
	self.greySpriteArray = {}
	self.startPoint = {}
	self.rightRects = {}
	self.selectSprite = nil
	self.selectValue = nil
	self.angleArray = {}

	--1为有数据在这个位置，0为该位置没数据
	self.matrixFlag = {}
	for i=1,COL do
		self.matrixFlag[i] = {}
		for j=1,ROW do
			self.matrixFlag[i][j] = 0
		end
	end

	for i = 3, 4 do
		self.matrixFlag[3][i] = 1
	end

	self.s = {}
 	for i=1,#str do
 		self.s[#self.s + 1] = string.sub(str,i,i)
 	end

	local overallLen = 0
	for i=1,#self.s do
		local isGreyIdx = false
		local imgname_grey = nil
		local imgname = nil
		local imgname_blank = nil
		for j=1,#greyIdxs do
			if greyIdxs[j] == i then
				isGreyIdx = true
			end
		end
		--if isGreyIdx == true then
		imgname_grey = string.format("letters/lower/%s_grey.png",self.s[i])
		--else
		imgname = string.format("letters/lower/%s.png",self.s[i])
		--end
		imgname_blank = string.format("letters/lower/%s_blank.png",self.s[i])

		--灰色精灵
		self.greySpriteArray[#self.greySpriteArray + 1] = display.newSprite(imgname_grey)
		local size = self.greySpriteArray[i]:getContentSize()
		self.greySpriteArray[i]:pos(overallLen + size.width / 2,0)

		self.lowSpriteArray[#self.lowSpriteArray + 1] = display.newSprite(imgname)
		self.lowSpriteArray[i]:pos(overallLen + size.width / 2,0)

		--空白精灵
		self.blankSpriteArray[#self.blankSpriteArray + 1] = display.newSprite(imgname_blank)
		self.blankSpriteArray[i]:pos(overallLen + size.width / 2,0)

		overallLen = overallLen + size.width
	end

	for i=1,#self.lowSpriteArray do
		local x = self.lowSpriteArray[i]:getPositionX()
		self.lowSpriteArray[i]
		:pos(x - overallLen / 2,0)
		:addTo(self)

		self.greySpriteArray[i]
		:pos(x - overallLen / 2,0)
		:setVisible(false)
		:addTo(self)

		self.blankSpriteArray[i]
		:pos(x - overallLen / 2,0)
		:addTo(self)
	end

	self:addLettesResponse()
	self:playWord()
	self:setRigthRects()


end

function Word:playWord()
	for i=1,#self.lowSpriteArray do
		local angle = math.random(-15,15)
		transition.rotateTo(self.lowSpriteArray[i], {rotate = angle, time = 0.5})
	end

	local sequence = transition.sequence({
	    cc.ScaleTo:create(0.5,1.1),
	    cc.ScaleTo:create(0.5,1.0),
	})
	self:runAction(sequence)

	--播放提示语音
	playSound(self.words)

	self:playUpsetAnimation()
end

function Word:playUpsetAnimation()
	local sprite = display.newSprite()
	:pos(-display.cx - 100,0)
	:addTo(self)

	display.addSpriteFrames("animation/5_stampede.plist", "animation/5_stampede.png") 
  	local animals = display.newSprite()
  	:pos(150,0)
  	:addTo(sprite)
  	local frames = display.newFrames("5_stampede_%d.png", 0, 3)
  	local animation = display.newAnimation(frames, 2.8/14.0)
  	animals:playAnimationForever(animation)
  	animals:setFlipX(true)

  	display.addSpriteFrames("animation/bull.plist", "animation/bull.png") 
  	local bull = display.newSprite()
  	:pos(-150,0)
  	:addTo(sprite)
  	local bullframes = display.newFrames("bull_%d.png", 0, 3)
  	local bullanimation = display.newAnimation(bullframes, 2.8/14.0)
  	bull:playAnimationForever(bullanimation)
  	bull:setFlipX(true)

    transition.moveTo(sprite, {
	x = display.cx + 100,
    time = 3.5,
    onComplete = function ()
    	sprite:removeFromParent()
    end,
    })

    local sequence = transition.sequence({
	    cc.DelayTime:create(1.5),
	    cc.CallFunc:create(handler(self, function ()
	    	audio.playSound("letters/sound/full_stampede.mp3")
	    	self:playUpsetLetters()
	    end)),
	})
	self:runAction(sequence)
end

function Word:playUpsetLetters()
	for i=1,#self.s do
		local col = math.random(1,COL)
		local row = math.random(1,ROW)
		while self.matrixFlag[col][row] == 1 do
			col = math.random(1,COL)
			row = math.random(1,ROW)
		end
		self.matrixFlag[col][row] = 1

		transition.moveTo(self.lowSpriteArray[i], {
			x = startx + (row - 1) * dx,
			y = starty + (col - 1) * dy,
			time = 0.2,
			onComplete = function ()
				local angle = math.random(-30,30)
				local turns = math.random(1,2)
				self.angleArray[#self.angleArray + 1] = angle * (-1)
				angle = turns * 360 + angle
				transition.rotateTo(self.lowSpriteArray[i], {rotate = angle, time = 0.5})
			end,
			})

		transition.moveTo(self.blankSpriteArray[i], {
			x = startx + (row - 1) * dx,
			y = starty + (col - 1) * dy,
			time = 0.2,
			onComplete = function ()
				local angle = math.random(-30,30)
				local turns = math.random(1,2)
				angle = turns * 360 + angle
				transition.rotateTo(self.blankSpriteArray[i], {rotate = angle, time = 0.5})
			end,
			})
	end

	for i=1,#self.greySpriteArray do
		self.greySpriteArray[i]:setVisible(true)
	end	
end

function Word:addLettesResponse()
	for i=1,#self.blankSpriteArray do
		self.blankSpriteArray[i]:setTouchEnabled(true)
		self.blankSpriteArray[i]:setTouchSwallowEnabled(false) 
		self.blankSpriteArray[i]:setTouchMode(cc.TOUCHES_ALL_AT_ONCE)        
		self.blankSpriteArray[i]:addNodeEventListener(cc.NODE_TOUCH_EVENT,function(event)
	 		if event.name == "began" then
	 			if self.selectSprite == nil then
	 				audio.playSound("letters/sound/word_select.mp3")
		 			self.selectSprite = self.blankSpriteArray[i]
		 			self.selectValue = self.s[i]
		 			self.startPoint[1] = self.blankSpriteArray[i]:getPositionX()
			 		self.startPoint[2] = self.blankSpriteArray[i]:getPositionY()
			 		self.lowSpriteArray[i]:setVisible(false)
		 			self:playLetterAnimation(i)
		 			playSound(self.s[i])
		 			--local path = string.format("letters/sound/%s-long.mp3",self.s[i])
		 			--audio.playSound(path)
	 			end
	        elseif event.name == "added" then
	        	
	        elseif event.name == "moved" then
	        	if self.selectSprite ~= nil and self.selectSprite == self.blankSpriteArray[i] then
		        	local p = self:convertToNodeSpaceAR(cc.p(event.points["0"]["x"],event.points["0"]["y"]))
		        	local isInRect,rigthIdx = self:isInRightRect(p,self.s[i])
		        	if isInRect == true then
		 				local x = self.greySpriteArray[rigthIdx]:getPositionX()
						local y = self.greySpriteArray[rigthIdx]:getPositionY()
		        		self.lowSpriteArray[i]:setVisible(true)
		        		self.blankSpriteArray[i]:pos(x,y)
		        		self.blankSpriteArray[i]:setTouchEnabled(false)
		        		self.selectSprite = nil
		        		self.selectValue = nil
		        		self.tempSprite:removeFromParent()
		        		self.tempSprite = nil
		        		local sequence = transition.sequence({
		        			cc.MoveTo:create(0.5,cc.p(x,y)),
						    cc.RotateTo:create(0.5,0),
						   	cc.ScaleTo:create(0.3,1.1),
	    					cc.ScaleTo:create(0.3,1.0),
	    					cc.CallFunc:create(handler(self, function ()
	    						playSound(self.s[i])
	    						audio.playSound("letters/sound/word_celebration.mp3")
	    					end)),
						})
						self.lowSpriteArray[i]:runAction(sequence)
						if self:isFinished() == true then
							PlayerData.wordArrayStartIdx = PlayerData.wordArrayStartIdx + 1
							GameState.save(PlayerData)
							self:getParent().wordsArray[#self:getParent().wordsArray + 1] = self.words
							local seq = transition.sequence({
								cc.DelayTime:create(1.6),
		    					cc.ScaleTo:create(0.5,1.1),
	    						cc.ScaleTo:create(0.5,1.0),
	    						cc.CallFunc:create(handler(self, function ()
	    							playSound(self.words)
	    							audio.playSound("letters/sound/sentence_celebration.mp3")
	    						end)),
	    						cc.CallFunc:create(handler(self, function ()
	    							self:displayRightPaticle()
    								local particle1 = cc.ParticleSystemQuad:create("particles/confetti_confetti_1.plist")
									:pos(0,display.cy - 50)
									:addTo(self)
	    						end)),
	    						cc.DelayTime:create(2.0),
	    						cc.CallFunc:create(handler(self, function ()
	    							local event = cc.EventCustom:new(CREATE_WORD_SPRITE)
						    		local dispatcher = cc.Director:getInstance():getEventDispatcher()
							    	dispatcher:dispatchEvent(event)
	    						end)),
							})
							self:runAction(seq)
						end
		        	else 
		        		self.lowSpriteArray[i]:pos(p.x,p.y)
		        		self.blankSpriteArray[i]:pos(p.x,p.y)
		        	end
	        	end
	        elseif event.name == "removed" then
	        elseif event.name == "ended" then
		        if self.selectSprite ~= nil and self.selectSprite == self.blankSpriteArray[i] then
		        	self.selectSprite = nil
		        	self.selectValue = nil
		        	self.tempSprite:removeFromParent()
		        	self.tempSprite = nil
		        	self.lowSpriteArray[i]:pos(self.startPoint[1],self.startPoint[2])
		        	self.lowSpriteArray[i]:setVisible(true)
		        	self.blankSpriteArray[i]:pos(self.startPoint[1],self.startPoint[2])
		        end
	        end 
	    	return true	
		end)
	end
end

function Word:playLetterAnimation(idx)
	local size = self.blankSpriteArray[idx]:getContentSize()
	self.tempSprite = display.newSprite()
	:pos(size.width / 2,size.height / 2)
  	:addTo(self.blankSpriteArray[idx])
  	--string.lower(s)
  	local frames = display.newFrames(string.upper(self.s[idx]) .. "_0%d.png", 1, 7)
  	local animation = display.newAnimation(frames, 2.8/14.0)
  	self.tempSprite:playAnimationForever(animation)
end

function Word:setRigthRects()
	for i=1,#self.greySpriteArray do
		local x = self.greySpriteArray[i]:getPositionX()
		local y = self.greySpriteArray[i]:getPositionY()
		local size = self.greySpriteArray[i]:getContentSize()
		local width = size.width
		local height = size.height
		self.rightRects[#self.rightRects + 1] = {}
		self.rightRects[i]["x"] = x - width / 2
		self.rightRects[i]["y"] = y - height / 2
		self.rightRects[i]["width"] = width
		self.rightRects[i]["height"] = height
	end
end

function Word:isInRightRect(point,s)
	for i=1,#self.s do
		if self.rightRects[i] ~= nil
		and	point.x > self.rightRects[i]["x"] 
		and point.x < self.rightRects[i]["x"] + self.rightRects[i]["width"]
		and point.y > self.rightRects[i]["y"]
		and point.y < self.rightRects[i]["y"] + self.rightRects[i]["height"] then
			if self.selectValue == self.s[i] then
				self.rightRects[i] = nil
				return true,i
			end
		end
	end
	return false
end

function Word:isFinished()
	for i=1,#self.s do
		if self.rightRects[i] ~= nil then
			return false
		end
	end
	return true
end

function Word:displayRightPaticle()
	local points = {}
	for i=1,6 do
		x = math.random(-display.cx + 50,display.cx - 50)
		y = math.random(-display.cy + 100,display.cy - 50)
		points[i] = {x,y}
	end

	for i=1,#points do
		local sequence = cc.Sequence:create(
			cc.DelayTime:create(0.5 * i),
			cc.CallFunc:create(handler(self, function ()
				local particle = cc.ParticleSystemQuad:create("particles/puff_candy.plist")
				:pos(points[i][1],points[i][2])
				:setZOrder(1000)
				:addTo(self)
			end)),
			nil)  
		self:runAction(sequence)
	end
end

return Word
