MSG_SPEECH_EVENT = "msg_speech_event"

StoryData = nil

function loadStoryData()
	if StoryData == nil then
		StoryData = json.decode(cc.HelperFunc:getFileData("data.json"))
	end
end

--主场景
g_mainScene = nil

g_selectLevel = nil


colorIndex = nil



loadStoryData()

entryAreaArray = {
--	{xstart,xend,ystart,yend}
	{-50,0,-50,display.cy * 2 + 50},
	{display.cx * 2,display.cx * 2 + 50,-50,display.cy * 2 + 50},
	{-50,display.cx * 2 + 50,-50,0},
	{-50,display.cx * 2 + 50,display.cy * 2,display.cy * 2 + 50}
}

levelselect_bg = {
	"home/study_digital/bg_digital.png",
	"home/study_letters/bg_abc.png",
}

study_digital = {
	{"home/study_digital/one_to_nine.png","home/study_digital/study1-9.png","app.bird.DigitalStudyLayer",{}},
	{"home/study_digital/zwsz.png","home/study_digital/study_chinadigital.png","app.clown.KnowColorLayer",{}},
	{"home/study_digital/ss.png","home/study_digital/study_math.png","app.train.TrainLayer",{}},
	{"home/ddy.png","home/ddy_title.png","",{}}
}

study_letter = {
	{"home/study_letters/xdx.png","home/study_letters/xdx_title.png","app.balloon.BalloonBearLayer",{3}},
	{"home/study_letters/xxx.png","home/study_letters/xxx_title.png","app.balloon.BalloonBearLayer",{4}},
	{"home/study_letters/xdc.png","home/study_letters/xdc_title.png","app.letter.LetterLayer",{}},
	{"home/ddy.png","home/ddy_title.png","",{}}
}


GameState=require("framework.cc.utils.GameState")

GameState.init(function(param)
    local returnValue=nil

    if  param.name=="load" then
         --文件出错了 重新加载
        if param.errorCode then
           -- CCLuaLog("error")
           local data = cc.FileUtils:getInstance():getStringFromFile("Data/playerData.json")
           print(data)
           local playerJson = json.decode(data)
           GameState.save(playerJson)
           returnValue=json.decode(str)
        else
            local str =param.values.data
            --local str=crypto.decryptXXTEA(str, "abcd")
            returnValue=json.decode(str)
            print("load Data")
        end


    elseif param.name=="save" then
            local str=json.encode(param.values)
            --str=crypto.encryptXXTEA(str, "abcd")
            returnValue={data=str}
            print("save Data")

    end

    return returnValue
end, "playerData.dat","ptyl")


PlayerData = GameState.load()
if PlayerData == nil then --第一次运行游戏
     PlayerData = GameState.load()
     if PlayerData == nil then
        PlayerData = {}
        PlayerData.wordArrayStartIdx = 1
        GameState.save(PlayerData)
     end
end