LevelButton = class("LevelButton", function()
    return display.newSprite()
end)

function LevelButton:ctor(imgNormal,imgPress,strTitle,functionCallBack)
	cc.ui.UIPushButton.new({ normal = imgNormal, pressed = imgPress })
    :onButtonClicked(functionCallBack)
    :setTouchSwallowEnabled(false)
    :addTo(self) 

    cc.ui.UILabel.new({UILabelType = 2, text = strTitle, size = 25,color = cc.c3b(255,0,0),})
	:align(display.CENTER, 0, 0)
	:addTo(self)
	
end

return LevelButton