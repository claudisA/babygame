require("app.balloon.BalloonBear")
require("app.GlobalData")
require("app.balloon.data")
require("app.HomePage")
require("app.bird.DigitalStudyLayer")
require("app.bird.ListenDigitalLayer")
require("app.train.TrainLayer")
require("app.letter.LetterLayer")

MainScene = class("MainScene", function()
    return display.newScene("MainScene")
end)

function MainScene:ctor()

	math.randomseed(os.time()) 
	
	local bg = display.newSprite("home/bg.png")
		:pos(display.cx, display.cy)

	local size = bg:getContentSize()
	bg:setScale(display.cx * 2 / size.width, display.cy * 2 / size.height)
	bg:addTo(self)

    cc.ui.UILabel.new({
            UILabelType = 2, text = "", size = 64})
        :align(display.CENTER, display.cx, display.cy)
        :addTo(self)


    --self.balloonBearLayer = BalloonBearLayer.new():addTo(self)
    self.homePage = HomePage.new():addTo(self)
    --self.digitalStudyLayer = DigitalStudyLayer.new():addTo(self)
    --self.listenDigitalLayer = ListenDigitalLayer.new():addTo(self)
    --self.trainLayer = TrainLayer.new():addTo(self)
    --self.letterLayer = LetterLayer.new():addTo(self)

	g_mainScene = self

end




return MainScene
