require("app.luaCallJava")
require("app.GlobalData")
local GiftBox = import("app.clown.GiftBox")
local BubbleButton = import("app.common.BubbleButton")

KnowColorLayer = class("KnowColorLayer", function()
    return display.newLayer()
end)


function KnowColorLayer:ctor()
	self.modname = "app.clown.KnowColorLayer"

	math.randomseed(os.time())

	local bg = display.newSprite("clown_bg.jpg")
	:pos(display.cx, display.cy)
	local size = bg:getContentSize()
	bg:setScale(display.cx * 2 / size.width, display.cy * 2 / size.height)
	bg:addTo(self)

	--添加返回按钮
	self.backButton = BubbleButton.new({
        image = "common/back2.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
           	--停止播放生成声音
        	stopSpeeking()
        	if g_selectLevel ~= nil then
        		g_selectLevel:setButtonEnabled(true)
        	end
           	self:removeFromParent()
        end,
    })
    :pos(display.cx * 2 - 70, display.cy * 2 - 40)
    :addTo(self)

	--添加录音按钮
	cc.ui.UIPushButton.new({ normal = "common/record.png", pressed = "common/record_down.png" })
    :onButtonClicked(function()
    	if device.platform == "android" then
    		local javaClassName = "org/cocos2dx/lua/AppActivity"
        	local javaMethodName = "startSpeech"
        	local javaParams = {}
        	local javaMethodSig = "()V"
        	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
    	else
    	    self.GiftBox:removeFromParent()
			self:delayCreateGiftBox(0.2)
    	end

    end)
    :pos(100,  100)
    :addTo(self)


	local function displayAGiftBox()
		--等待段时间弹出小丑，等待语音播放完
		self:delayCreateGiftBox(0.5)
	end

	local sequence = cc.Sequence:create(
			--cc.CallFunc:create(handler(self, displayDoor)),
			cc.DelayTime:create(0.5),
			cc.CallFunc:create(handler(self, displayAGiftBox)),
			nil)  
	self:runAction(sequence)
     
   	--打开节点进入退出响应
    self:setNodeEventEnabled(true)

    -- 1.获取事件分发器  : EventDispatcher
    local dispatcher = cc.Director:getInstance():getEventDispatcher()

    -- 语音接收响应
    local listener = cc.EventListenerCustom:create(MSG_SPEECH_EVENT, handler(self,self.handerSpeeech))

    dispatcher:addEventListenerWithSceneGraphPriority(listener, self)

    if device.platform == "android"  then
    	-- 将functionId 传给java
		local javaClassName = "org/cocos2dx/lua/Iat"
	    local javaMethodName = "registerLuaCallback"
	    local javaParams = {
	        function(data)
	        	local event = cc.EventCustom:new(MSG_SPEECH_EVENT)
	        	event.userdata = data
	    		dispatcher:dispatchEvent(event) 
	        end
	    }
	    
	    local javaMethodSig = "(I)V"
	    luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
    end
end	

function KnowColorLayer:displayAGiftBox()
	self.GiftBox = GiftBox.new({
        image = "giftbox.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.GiftBox:setButtonEnabled(false)
        end,
        listener = function()
        end,
    })
    :pos(display.cx, display.cy - 60)
    :addTo(self)
end

function KnowColorLayer:delayCreateGiftBox(time)
	local function createGiftBox()
		self:displayAGiftBox()
	end
	local sequence = cc.Sequence:create(
	cc.DelayTime:create(time),
	cc.CallFunc:create(handler(self, createGiftBox)),
	nil)
	self:runAction(sequence)
end


function KnowColorLayer:handerSpeeech(event)
	local color_array = StoryData["flower_color"]
	local hasHandle = false
	for i=1, #color_array do
		if color_array[index] == event.userdata then
			--播放小朋友你真棒，小朋友你好聪明哦，等等语音
			playSound(StoryData["compliments"][1])
			--创建下一个礼物盒子
			self.GiftBox:removeFromParent()
			self:delayCreateGiftBox(1.0)
			hashandle = true
			break			
		end
	end

	if hasHandle == false and event.userdata ~= "。" then
		playSound(StoryData["encourage"][1])
		self.GiftBox:removeFromParent()
		self:delayCreateGiftBox(0.2)
	end
end

function KnowColorLayer:stopCreateSprite()

end

function KnowColorLayer:onEnter()

end

function KnowColorLayer:onExit()

end	


return KnowColorLayer