require("app.luaCallJava")
require("app.GlobalData")

local GiftBox = {}

function GiftBox.new(params)

	GiftBox.color = nil

    local listener = params.listener
    local box -- pre-reference

    params.listener = function(tag)
        if params.prepare then
            params.prepare()
        end

        local function zoom1(offset, time, onComplete)
            local x, y = box:getPosition()
            local size = box:getContentSize()
            size.width = 200
            size.height = 200

            local scaleX = box:getScaleX() * (size.width + offset) / size.width
            local scaleY = box:getScaleY() * (size.height - offset) / size.height

            transition.moveTo(box, {y = y - offset, time = time})
            transition.scaleTo(box, {
                scaleX     = scaleX,
                scaleY     = scaleY,
                time       = time,
                onComplete = onComplete,
            })
        end

        local function zoom2(offset, time, onComplete)
            local x, y = box:getPosition()
            local size = box:getContentSize()
            size.width = 200
            size.height = 200

            transition.moveTo(box, {y = y + offset, time = time / 2})
            transition.scaleTo(box, {
                scaleX     = 1.0,
                scaleY     = 1.0,
                time       = time,
                onComplete = onComplete,
            })
        end


        --弹出小丑
        local function popClown()
        	local role_index = math.random(1,6)
        	local clown = display.newSprite(string.format("clown/clown_%02d.png",4))
        	:addTo(box)
        	
        	local Index = math.random(1,7)
        	GiftBox.color = color_array[Index]
        	local flower = display.newSprite(string.format("flower/flower_%02d.png",Index))
        	:setScale(0.4)
        	:pos(-30, 165)
        	:addTo(clown)

        	flower:runAction(cc.RepeatForever:create(CCRotateBy:create(0.2, 30)))
       
        	transition.execute(clown,CCMoveTo:create(1.5,cc.p(0,100)),{
        		--delay = 1.0,
        		easing = "elasticOut",--bounceOut,backout,(elasticOut),exponentialOut,sineOut,Out
        		onComplete = function()
        			print("move complete")
        			--播放花的颜色语音
					playLevelSound(StoryData["flower_color"][Index],0)
        		end,
        		})
        	--]]
        end	


        box:setButtonEnabled(false)

        zoom1(40, 0.01, function()
            zoom2(40, 0.02, function()
                zoom1(20, 0.03, function()
                    zoom2(20, 0.04, function()
                        box:setButtonEnabled(true)
                        listener(tag)
                        popClown()
                    end)
                end)
            end)
        end)
    end

    box =  cc.ui.UIPushButton.new({normal = params.image})


    local sequence = cc.Sequence:create(
	cc.DelayTime:create(0.3),
	cc.CallFunc:create(handler(box, function ()
        params.listener("")
    end)),
	nil)
    box:runAction(sequence)

    box:onButtonClicked(function(tag)
        --params.listener(tag)
    end)
    return box
end

return GiftBox
