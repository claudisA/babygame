require("app.balloon.Cloud")
require("app.bird.Bird")
require("app.bird.RightOrError")
require("app.balloon.data")
require("app.bird.ResultPanel")
require("app.GlobalData")
require("app.luaCallJava")
require("app.utils.ShaderUtil")


local BubbleButton = import("app.common.BubbleButton")

DigitalStudyLayer = class("DigitalStudyLayer", function()
    return display.newLayer()
end)

function DigitalStudyLayer:ctor()
	self.modname = "app.bird.DigitalStudyLayer"

	self.studyDigitals = {}
	self.rightCount = 0
	self.digitals = {}

	local bg = display.newSprite("bird/bg_night2.jpg")
	:pos(display.cx, display.cy)

	local size = bg:getContentSize()
	bg:setScale(display.cx * 2 / size.width, display.cy * 2 / size.height)
	bg:addTo(self)

	--播放粒子效果
	local particle1 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx / 4 * 2,display.cy * 2 - 100)
	:addTo(self)

	local particle2 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx / 4 * 3,display.cy * 2 - 100)
	:addTo(self)

	self.digitalSpriteCount = 0
	--保存精灵的数组
	self.digitalSpriteArray = {}
	self:createDigitalSprite(1)

	--添加返回按钮
	self.backButton = BubbleButton.new({
        image = "common/back2.png",
        sound = nil,
        prepare = function()
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
        	--停止播放生成声音
        	stopSpeeking()
        	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
        	if g_selectLevel ~= nil then
        		g_selectLevel:setButtonEnabled(true)
        	end
           	self:removeFromParent()
        end,
    })
    :pos(display.cx * 2 - 70, display.cy * 2 - 40)
    :addTo(self)

	--添加录音按钮
	self.recordBtn = cc.ui.UIPushButton.new({ normal = "common/record.png", pressed = "common/record_down.png" })
    :onButtonClicked(function()
    	if device.platform == "android" then
    		local javaClassName = "org/cocos2dx/lua/AppActivity"
        	local javaMethodName = "startSpeech"
        	local javaParams = {}
        	local javaMethodSig = "()V"
        	luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
    	end
    end)
    :pos(100,  100)
    :addTo(self)
    --标示按钮有效无效的精灵
    self.sp = display.newSprite("common/record.png"):addTo(self)
    self.sp:setPosition(100,  100)

	-- 1.获取事件分发器  : EventDispatcher
    local dispatcher = cc.Director:getInstance():getEventDispatcher()

    -- 语音接收响应
    local listener1 = cc.EventListenerCustom:create(MSG_SPEECH_EVENT, handler(self,self.handerSpeeech))

    dispatcher:addEventListenerWithSceneGraphPriority(listener1, self)

    -- 接受数字点击响应
    local listener2 = cc.EventListenerCustom:create(MSG_CLICK_DIGITAL_EVEN, handler(self,self.handleCustome))

    dispatcher:addEventListenerWithSceneGraphPriority(listener2, self)

    --打开节点进入退出响应
    self:setNodeEventEnabled(true)

    if device.platform == "android"  then
    	-- 将functionId 传给java
		local javaClassName = "org/cocos2dx/lua/Iat"
	    local javaMethodName = "registerLuaCallback"
	    local javaParams = {
	        function(data)
	        	local event = cc.EventCustom:new(MSG_SPEECH_EVENT)
	        	event.userdata = data
	    		dispatcher:dispatchEvent(event) 
	        end
	    }
	    
	    local javaMethodSig = "(I)V"
	    luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
    end 
	
    local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerID = nil  
    self.schedulerID  = scheduler:scheduleScriptFunc(function()
    		self:removeAllChildren()
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID )
            local ResultPanel = ResultPanel.new(self.digitals,self.rightCount)
            :pos(display.cx,display.cy)
            :setZOrder(1000)
            :addTo(self)
    end,120,false) 
end


function DigitalStudyLayer:createDigitalSprite(count)
	self.digitalSpriteCount = self.digitalSpriteCount + count
	for i=1,count do
		--保证每次弹出的数字不一样
		if #self.studyDigitals == 0 then
			for i=1,10 do
				self.studyDigitals[#self.studyDigitals + 1] = i
			end
		end

		local index = math.random(1,#self.studyDigitals)
		local digital = self.studyDigitals[index]
		table.remove(self.studyDigitals,index)

		--index = math.random(11,20)
		--y = math.random(200,display.cy * 2 - 50)

		--[[
		--创建云彩数字
		local sprite = Cloud.new(index)
		:pos(-100, y)
		:addTo(self)
		--]]

		local idx1 = math.random(1,#entryAreaArray)
		local rx = math.random(entryAreaArray[idx1][1],entryAreaArray[idx1][2])
		local ry = math.random(entryAreaArray[idx1][3],entryAreaArray[idx1][4])

		--创建小鸟数字
		sprite = Bird.new(digital)
		:pos(rx,ry)
		:addTo(self)

		sprite.sBird:setButtonEnabled(false)

		transition.moveTo(sprite, {
			x = display.cx,
			y = display.cy,
			time = 2,
			onComplete = function ()
				if sprite ~= nil then
					--sprite:removeFromParent()
				end
				sprite.sBird:setButtonEnabled(true)
				--播放提示语音
				playSound(StoryData["bird"][1])

				--self:createDigitalSprite(1)
			end})

		--将精灵数据保存到数组中
		self.digitalSpriteArray[#self.digitalSpriteArray + 1] = sprite
	end
	
	--[[
	if self.digitalSpriteCount == count then
		local scheduler = cc.Director:getInstance():getScheduler()
 		self.schedulerID = scheduler:scheduleScriptFunc(function()
 			self:createDigitalSprite(count)
 		end,16,false)  
	end
	--]]
end

function DigitalStudyLayer:handerSpeeech(event)
	for i=1,#self.digitalSpriteArray do
		if event.userdata == tostring(self.digitalSpriteArray[i].digital) and event.userdata ~= "。" then
			stopListening()
			self.rightCount = self.rightCount + 1
			local sprite = self.digitalSpriteArray[i]
			playSound(StoryData["bird"][2])
			--self.digitals[#self.digitals + 1] = sprite.digital
			self:addRightDigital(sprite.digital)
			table.remove(self.digitalSpriteArray,i)
			self:reorderChild(sprite, TAG_MAX_ZORDER)
			self:decompose(sprite)
			--playSound(StoryData["compliments"][1])
			break
		end

		if event.userdata ~= tostring(self.digitalSpriteArray[i].digital) and event.userdata ~= "。" then
			--按钮设置成点击无效
			darkNode(self.sp)
			self.recordBtn:setButtonEnabled(false)

			local sprite = self.digitalSpriteArray[i]
			table.remove(self.digitalSpriteArray,i)

			transition.moveTo(sprite, {
			x = display.cx - 90,
			time = 0.5,
			onComplete = function ()

			end})

			rightOrError = RightOrError.new(false,sprite.digital)
			:setScale(0.8)
			:pos(display.cx,display.cy)
				:addTo(self) 

			transition.moveTo(rightOrError, {
			x = display.cx + 90,
			time = 0.5,
			onComplete = function ()
				self:displayRightPaticle()
			end})

			stopListening()
			audio.playSound("sound/bird_sad.wav")
			local sequence = cc.Sequence:create(
			cc.DelayTime:create(0.2),
			cc.CallFunc:create(handler(self, function ()
				playSound(string.format(StoryData["bird"][3],sprite.digital))
			end)),
			cc.DelayTime:create(8),
			cc.CallFunc:create(handler(self, function ()
				sprite:removeFromParent()
				rightOrError:removeFromParent()
				self:createDigitalSprite(1)
				--回复按钮可点击
				self.sp:setGLProgramState(cc.GLProgramState:getOrCreateWithGLProgram(cc.GLProgramCache:getInstance():getGLProgram("ShaderPositionTextureColor_noMVP")))
				self.recordBtn:setButtonEnabled(true)
			end)),
			nil)  

			self:runAction(sequence)
			
			break
		end

	end
end	

function DigitalStudyLayer:handleCustome(event)
	for i=1,#self.digitalSpriteArray do
		if event.userdata == self.digitalSpriteArray[i] and event.userdata.digital == self.digitalSpriteArray[i].digital then
			local sprite = self.digitalSpriteArray[i]
			table.remove(self.digitalSpriteArray,i)
			self:reorderChild(sprite, TAG_MAX_ZORDER)
			--sprite:decompose()

			--self.digitals[#self.digitals + 1] = sprite.digital
			self:addRightDigital(sprite.digital)
			self:decompose(sprite)
			break
		end
	end
end

function DigitalStudyLayer:decompose(_sprite)
	transition.moveTo(_sprite, {
	x = display.cx - 90,
	time = 0.5,
	onComplete = function ()

	end})


	rightOrError = RightOrError.new(true,_sprite.digital)
	:setScale(0.8)
	:pos(display.cx,display.cy)
		:addTo(self) 

	transition.moveTo(rightOrError, {
	x = display.cx + 90,
	time = 0.5,
	onComplete = function ()
		self:displayRightPaticle()
	end})

	--进入下一次问答
	local sequence = cc.Sequence:create(
	cc.DelayTime:create(4),
	cc.CallFunc:create(handler(self, function ()
		sprite:removeFromParent()
		rightOrError:removeFromParent()
		self:createDigitalSprite(1)

	end)),
	nil)  
	self:runAction(sequence)
end

function DigitalStudyLayer:displayRightPaticle()
	local points = {}
	for i=1,6 do
		x = math.random(display.cx - 200,display.cy + 200)
		y = math.random(display.cy - 100,display.cy + 300)
		points[i] = {x,y}
	end

	for i=1,#points do
		local sequence = cc.Sequence:create(
			cc.DelayTime:create(0.5 * i),
			cc.CallFunc:create(handler(self, function ()
				local particle = cc.ParticleSystemQuad:create("particles/win_star.plist")
				:pos(points[i][1],points[i][2])
				:setZOrder(1000)
				:addTo(self)
			end)),
			nil)  
		self:runAction(sequence)
	end
end

function DigitalStudyLayer:addRightDigital(digital)
	local hasSameDigital = false
	for i=1,#self.digitals do
		if self.digitals[i] == digital then
			hasSameDigital = true
			break
		end
	end

	if hasSameDigital == false then
		self.digitals[#self.digitals + 1] = digital
	end 
end

function DigitalStudyLayer:onEnter()

end

function DigitalStudyLayer:onExit()
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
	local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:removeEventListenersForTarget(self)
end	

return DigitalStudyLayer