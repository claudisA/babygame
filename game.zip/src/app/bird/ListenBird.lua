require("app.GlobalData")
require("app.luaCallJava")

ListenBird = class("ListenBird", function()
    return display.newSprite()
end)


function ListenBird:ctor(_digital)
	self.isFinished = false
	self.digital = _digital
	self.sBird = cc.ui.UIPushButton.new({ normal = "bird/bird.png", pressed = "bird/bird.png" })
    :onButtonClicked(function()
		--playSound(tostring(self.digital))
		playSound(string.format(StoryData["bird"][4],self.digital))
		local event = cc.EventCustom:new(MSG_CLICK_DIGITAL_EVEN)
		event.userdata = self
		-- 1.获取事件分发器  : EventDispatcher
		local dispatcher = cc.Director:getInstance():getEventDispatcher()
		dispatcher:dispatchEvent(event)
    end)
    :addTo(self)

    self.kuangBg = display.newSprite("bird/kuang_bg.png")
    :setScale(2.0)
    :pos(-10,-70)
    :addTo(self)

    self.redkuang = display.newSprite("bird/red_kuang.png")
    :setScale(1.5)
    :pos(0,-70)
    :addTo(self)

    local size = self.kuangBg:getContentSize()
    size.width = size.width * 2
    size.height = size.height * 2

    self.kuang_rect = {-10-size.width/2,-70-size.height/2,-10+size.width/2,-70+size.height/2}
end

function ListenBird:detectMoveIn(point,moveDigital)
	if self.isFinished == false then
		local p = self:convertToNodeSpaceAR(point)
		if p.x > self.kuang_rect[1] and p.x < self.kuang_rect[3] and p.y > self.kuang_rect[2] and p.y < self.kuang_rect[4] then

			if moveDigital == self.digital then
				self.digitallabel = CCLabelAtlas:_create(""..self.digital,"common/digital.png",76,115,string.byte('0'))
				:setAnchorPoint(0.5,0.5)
				:pos(-10,-70)
				:setScale(0.6)
				:addTo(self)
				self.isFinished = true
				return true,true
			else
				return true,false
			end
		else
			if moveDigital == self.digital then
				return false,true
			else
				return false,false
			end
		end
	end
	return false
end

return ListenBird