require("app.GlobalData")
require("app.luaCallJava")

RightOrError = class("RightOrError", function()
    return display.newSprite()
end)

function RightOrError:ctor(result,digital)
	self.bg = display.newSprite("bird/display_panel.png")
	:addTo(self)

	if result == true then
		audio.playSound("sound/bird_happy.wav")
		self.resultIcon = display.newSprite("bird/icon_right.png")
	else
		self.resultIcon = display.newSprite("bird/icon_error.png")	
	end
	self.resultIcon
	:setScale(0.4)
	:pos(0,-38)
	:addTo(self)
end


return RightOrError