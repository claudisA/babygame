require("app.bird.ListenBird")
require("app.utils.ShaderUtil")
require("app.GlobalData")
require("app.luaCallJava")

local BubbleButton = import("app.common.BubbleButton")

ListenDigitalLayer = class("ListenDigitalLayer", function()
    return display.newLayer()
end)

local dx = (display.cx * 2 - 200) / 6
local tips = 2
local selectdigitalcount = 5

function ListenDigitalLayer:ctor()
	self.modname = "app.bird.ListenDigitalLayer"
	self.rightdigitals = {}
	self.rightCount = 0
	self.errorCount = 0
	self.studyDigitals = {}
	self.moveIdx = nil
	self.moveDigital = nil
	self.selectDigitals = {}
	self.selectlabels = {}
	self.sl1 = {}

	self.sl2 = {}

	--播放背景音乐
	audio.playMusic("sound/gameplay.mp3", true)
	--audio.setEffectsVolume(0.5)

	--播放粒子效果
	local particle1 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx / 4 * 2,display.cy * 2 - 100)
	:addTo(self)

	local particle2 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx / 4 * 3,display.cy * 2 - 100)
	:addTo(self)

	self:createBird()

	self:addNodeEventListener(cc.NODE_TOUCH_EVENT,function(event)
        if event.name == "began" then

            if self:onTouchBegan(cc.p(event.x,event.y)) then
                return true
            end
            return false

        elseif event.name == "moved" then
            self:onTouchMoved(cc.p(event.x,event.y))
        elseif event.name == "ended" then
            self:onTouchEnded(cc.p(event.x,event.y))
        end
    end)
	self:setTouchSwallowEnabled(false) 
    self:createSelectDigitals()


    self:addNodeEventListener(cc.NODE_ENTER_FRAME_EVENT,function(dt) 
    	self:update(dt) 
    end)
    self:scheduleUpdate()  

   	--添加返回按钮
	self.backButton = BubbleButton.new({
        image = "common/back2.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
           	--停止播放生成声音
        	stopSpeeking()
        	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
        	if g_selectLevel ~= nil then
        		g_selectLevel:setButtonEnabled(true)
        	end
           	self:removeFromParent()
        end,
    })
    :pos(display.cx * 2 - 70, display.cy * 2 - 40)
    :addTo(self)

    local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerID = nil  
    self.schedulerID = scheduler:scheduleScriptFunc(function()
    		self:removeAllChildren()
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
            local ResultPanel = ResultPanel.new(self.rightdigitals,self.rightCount)
            :pos(display.cx,display.cy)
            :setZOrder(1000)
            :addTo(self)
    end,120,false)

    --打开节点进入退出响应
    self:setNodeEventEnabled(true)
end

function ListenDigitalLayer:onTouchBegan(point)
	return true
end

function ListenDigitalLayer:onTouchMoved(point)
end

function ListenDigitalLayer:onTouchEnded(point)
	local moveIn,answer = self.listenBird:detectMoveIn(point,self.moveDigital)
	if moveIn == true and answer == true then
		self:removeTips()
		self:setLabelable(false)
		self.rightCount = self.rightCount + 1
		local  canAdd = true
		for i=1,#self.rightdigitals do
			if self.listenBird.digital == self.rightdigitals[i] then
				canAdd = false
				break
			end
		end
		if canAdd == true then
			self.rightdigitals[#self.rightdigitals + 1] = self.listenBird.digital
		end 

		self.sl1[self.moveIdx]:removeFromParent()
		self.sl1[self.moveIdx] = nil
		self.sl2[self.moveIdx]:removeFromParent()
		self.sl2[self.moveIdx] = nil
		self.selectlabels[self.moveIdx]:removeFromParent()
		self.selectlabels[self.moveIdx] = nil
		self:decompose(self.listenBird)
		playSound(StoryData["bird"][2])
		audio.playSound("sound/SFX_Yeah.mp3")
	else
		self.errorCount = self.errorCount + 1
		if self.errorCount == 3 then
			self:removeTips()
			self:setLabelable(false)
			for i=1,#self.selectDigitals do
				if self.selectDigitals[i] == self.listenBird.digital then
					local x = self.selectlabels[i]:getPositionX()
					local y = self.selectlabels[i]:getPositionY()

					self.circlebg:pos(x,y)
					:setVisible(true)
					local act1 = CCTintTo:create(0.1, 255 * 1/3, 255 * 1/3, 255 * 1/3);
					local act2 = CCTintTo:create(0.1, 255, 255, 255);
					local sequence = cc.Sequence:create(act1,act2,nil)
					self.circlebg:runAction(CCRepeatForever:create(sequence))
					break
				end
			end

			transition.moveTo(self.listenBird, {
			x = display.cx - 90,
			time = 0.5,
			onComplete = function ()

			end})


			rightOrError = RightOrError.new(false,self.selectDigitals[self.moveIdx])
			:setScale(0.8)
			:pos(display.cx,display.cy + 100)
				:addTo(self) 

			transition.moveTo(rightOrError, {
			x = display.cx + 90,
			time = 0.5,
			onComplete = function ()

			end})

			audio.playSound("sound/bird_sad.wav")
			local sequence = cc.Sequence:create(
			cc.DelayTime:create(0.2),
			cc.CallFunc:create(handler(self, function ()
				playSound(string.format(StoryData["bird"][7],self.listenBird.digital))
			end)),
			cc.DelayTime:create(6),
			cc.CallFunc:create(handler(self, function ()
				self.listenBird:removeFromParent()
				rightOrError:removeFromParent()
				for i=1,#self.selectlabels do
					if self.selectlabels[i] ~= nil then
						self.selectlabels[i]:removeFromParent()
					end
					if self.sl1[i] ~= nil then
						self.sl1[i]:removeFromParent()
					end
					if self.sl2[i] ~= nil then
						self.sl2[i]:removeFromParent()
					end
				end
				self.circlebg:removeFromParent()
				self.circlebg = nil
				self.selectlabels = {}
				self.sl1 = {}
				self.sl2 = {}
				self.selectDigitals = {}
				self:createBird()
				self:createSelectDigitals()
				self.errorCount = 0
			end)),
			nil)

			self:runAction(sequence)
		end

		self.sl1[self.moveIdx]:pos(100 + dx * self.moveIdx,130)
		self.sl2[self.moveIdx]:setGLProgramState(cc.GLProgramState:getOrCreateWithGLProgram(cc.GLProgramCache:getInstance():getGLProgram("ShaderPositionTextureColor_noMVP")))
	end
end

function ListenDigitalLayer:update(dt)
	
end

function ListenDigitalLayer:setLabelable(able)
	for i=1, selectdigitalcount do
		if self.selectlabels[i] ~= nil then
			if able == true then
				self.selectlabels[i]:setTouchEnabled(true)
			else
				self.selectlabels[i]:setTouchEnabled(false)
			end
		end
	end
end

function ListenDigitalLayer:createSelectDigitals()
	self:setTouchEnabled(false)
	local studyDigitals = {}
	for i=1,10 do
		studyDigitals[#studyDigitals + 1] = 20 + i
	end
	table.remove(studyDigitals,self.listenBird.digital - 20)

	for i=1,4 do
		local index = math.random(1,#studyDigitals)
		self.selectDigitals[#self.selectDigitals + 1] = studyDigitals[index]
		table.remove(studyDigitals,index)
	end

	local idx = math.random(1,5)
	table.insert(self.selectDigitals,idx,self.listenBird.digital)

	--local dx = (display.cx * 2 - 200) / 6

	self.circlebg = display.newSprite("bird/circle_bg.png")
	:pos(100 + dx, 130)
	:setVisible(false)
	:addTo(self)
	
	for i=1,#self.selectDigitals do

		self.selectlabels[#self.selectlabels + 1] = CCLabelAtlas:_create(""..self.selectDigitals[i],"common/digital.png",76,115,string.byte('0'))
		:setAnchorPoint(0.5,0.5)
		:pos(display.cx * 2 + 50, 130)
		:setScale(0.6)
		:addTo(self)

		local sequence = cc.Sequence:create(
			cc.DelayTime:create(0.2 * (i - 1)),
			cc.CallFunc:create(handler(self, function ()
				local act = cc.MoveTo:create(2,cc.p(100 + dx * i, 130))
				local speed = CCSpeed:create(act,5)
				self.selectlabels[i]:runAction(speed)
			end)),
			cc.DelayTime:create(1.0),
			cc.CallFunc:create(handler(self, function ()

				self.sl1[#self.sl1 + 1] = CCLabelAtlas:_create(""..self.selectDigitals[i],"common/digital.png",76,115,string.byte('0'))
				:setAnchorPoint(0.5,0.5)
				:pos(100 + dx * i, 130)
				:setScale(0.6)
				:addTo(self)

				self.sl2[#self.sl2 + 1] = CCLabelAtlas:_create(""..self.selectDigitals[i],"common/digital.png",76,115,string.byte('0'))
				:setAnchorPoint(0.5,0.5)
				:pos(100 + dx * i, 130)
				:setScale(0.6)
				:addTo(self)

				self.selectlabels[i]:setTouchEnabled(false)
				self.selectlabels[i]:setTouchSwallowEnabled(false) 
				self.selectlabels[i]:setTouchMode(cc.TOUCHES_ALL_AT_ONCE)        
				self.selectlabels[i]:addNodeEventListener(cc.NODE_TOUCH_EVENT,function(event)
				 		if event.name == "began" then
				 			self.moveIdx = i 
				 			self.moveDigital = self.selectDigitals[i]
				 			darkNode(self.sl2[i])
				        elseif event.name == "added" then
				        elseif event.name == "moved" then
				           	self.sl1[i]:pos(event.points["0"]["x"],event.points["0"]["y"])
				        elseif event.name == "removed" then
				        elseif event.name == "ended" then
				        end 
				    	 return true
					end)

				if i == #self.selectDigitals then
					self:gameTips()
				end
			end)),
		nil)  
		


		self:runAction(sequence)
		--]]
	end
	--print(table.concat(self.selectDigitals, "=="))
end

function ListenDigitalLayer:removeTips()
	if self.finger ~= nil then
		self.finger:removeFromParent()
		self.finger = nil
		self.tiplabel:removeFromParent()
		self.tiplabel = nil
	end
end

function ListenDigitalLayer:gameTips()	
	if tips >= 1 then
		local startx = nil
		local starty = nil
		local idx = nil
		self.tiplabel = nil
		tips = tips - 1
		for i=1,#self.selectDigitals do
			if self.listenBird.digital == self.selectDigitals[i] then

				self.tiplabel = CCLabelAtlas:_create(""..self.selectDigitals[i],"common/digital.png",76,115,string.byte('0'))
				:setAnchorPoint(0.5,0.5)
				:pos(100 + dx * i, 130)
				:setScale(0.6)
				:addTo(self)

				startx = self.selectlabels[i]:getPositionX() + 50
				starty = self.selectlabels[i]:getPositionY() - 50
				self.finger = display.newSprite("bird/finer.png")
				:pos(startx,starty)
				:addTo(self)
				idx = i

				break
			end
		end

		local mx = self.listenBird:getPositionX()
		local my = self.listenBird:getPositionY()
		local point = self:convertToWorldSpace(cc.p(mx,my))

		local times = 3

		local function playTips()
			transition.moveTo(self.tiplabel, {
		 	x = point.x,
		 	y = point.y - 50,
		 	time = 3,
		 	onComplete = function ()
		 		self.tiplabel:pos(100 + dx * idx, 130)
		 		if times == 0 then
		 			self:removeTips()
		 		end
		 	end})	

			transition.moveTo(self.finger, {
		 	x = point.x,
		 	y = point.y - 100,
		 	time = 3,
		 	onComplete = function ()
		 		if times > 1 then
		 			self.finger:pos(startx,starty)
		 			times = times - 1
		 			playTips()
		 		else
		 			self:removeTips()
		 		end
		 	end})	
		end

		playTips()

	end
end

function ListenDigitalLayer:createBird()
	--保证每次弹出的数字不一样
	if #self.studyDigitals == 0 then
		for i=1,10 do
			self.studyDigitals[#self.studyDigitals + 1] = 20 + i
		end
	end

	local index = math.random(1,#self.studyDigitals)
	local digital = self.studyDigitals[index]
	table.remove(self.studyDigitals,index)

	local idx1 = math.random(1,#entryAreaArray)
	local rx = math.random(entryAreaArray[idx1][1],entryAreaArray[idx1][2])
	local ry = math.random(entryAreaArray[idx1][3],entryAreaArray[idx1][4])

	self.listenBird = ListenBird.new(digital)
	:pos(rx,ry)
	:addTo(self)

	transition.moveTo(self.listenBird, {
		x = display.cx,
		y = display.cy + 100,
		time = 2,
		onComplete = function ()
			if self.listenBird ~= nil then
				--sprite:removeFromParent()
			end
			--播放提示语音
			playSound(string.format(StoryData["bird"][6],self.listenBird.digital))
			self:setTouchEnabled(true)
			self:setLabelable(true)
		end})
end

function ListenDigitalLayer:decompose(_sprite)
	transition.moveTo(_sprite, {
	x = display.cx - 90,
	time = 0.5,
	onComplete = function ()

	end})


	rightOrError = RightOrError.new(true,_sprite.digital)
	:setScale(0.8)
	:pos(display.cx,display.cy + 100)
		:addTo(self) 

	transition.moveTo(rightOrError, {
	x = display.cx + 90,
	time = 0.5,
	onComplete = function ()
		self:displayRightPaticle()
	end})

	--进入下一次问答
	local sequence = cc.Sequence:create(
	cc.DelayTime:create(4),
	cc.CallFunc:create(handler(self, function ()
		_sprite:removeFromParent()
		rightOrError:removeFromParent()
		for i=1,selectdigitalcount do
			if self.selectlabels[i] ~= nil then
				self.selectlabels[i]:removeFromParent()
			end
			if self.sl1[i] ~= nil then
				self.sl1[i]:removeFromParent()
			end
			if self.sl2[i] ~= nil then
				self.sl2[i]:removeFromParent()
			end
		end
		self.selectlabels = {}
		self.sl1 = {}
		self.sl2 = {}
		self.selectDigitals = {}
		self:createBird()
		self:createSelectDigitals()
		self.errorCount = 0
	end)),
	nil)  
	self:runAction(sequence)
end

function ListenDigitalLayer:displayRightPaticle()
	local points = {}
	for i=1,6 do
		x = math.random(display.cx - 200,display.cy + 200)
		y = math.random(display.cy - 100,display.cy + 300)
		points[i] = {x,y}
	end

	for i=1,#points do
		local sequence = cc.Sequence:create(
			cc.DelayTime:create(0.5 * i),
			cc.CallFunc:create(handler(self, function ()
				audio.playSound("sound/particle_sfx.mp3")
				local particle = cc.ParticleSystemQuad:create("particles/win_star.plist")
				:pos(points[i][1],points[i][2])
				:setZOrder(1000)
				:addTo(self)
			end)),
			nil)  
		self:runAction(sequence)
	end
end

function ListenDigitalLayer:onEnter()

end

function ListenDigitalLayer:onExit()
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.schedulerID)
end	

return ListenDigitalLayer