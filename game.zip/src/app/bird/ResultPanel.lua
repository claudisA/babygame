require("app.GlobalData")
require("app.luaCallJava")

local BubbleButton = import("app.common.BubbleButton")

ResultPanel = class("ResultPanel", function()
    return display.newSprite()
end)

function ResultPanel:ctor(digitals,rightcount)
	marklayer = cc.LayerColor:create(cc.c4b(0,0,0,220))
	:pos(-display.cx,-display.cy)
	:addTo(self)

	--播放粒子效果
	local particle1 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx * 2 / 3 * 1 - display.cx,display.cy - 100)
	:addTo(self)

	local particle2 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx * 2 / 3 * 2 - display.cx,display.cy - 100)
	:addTo(self)

	self.panel = display.newSprite("common/panel.png")
	:setScale(2.0)
	:addTo(self)

	local size = self.panel:getContentSize()
	size.width = size.width * 2.0
	size.height = size.height * 2.0

    cc.ui.UILabel.new({
        UILabelType = 2, text = "游戏结束", size = 34,color = cc.c3b(255,0,0)})
    :align(display.CENTER, 0, size.height / 2 - 30)
    :addTo(self)

    playSound(string.format(StoryData["bird"][5],rightcount))

    local str = "这次回答正确的数字分别是："
    cc.ui.UILabel.new({
    UILabelType = 2, text = str, size = 20,color = cc.c3b(0,255,0)})
    :align(display.CENTER, -size.width / 2 + 150, size.height / 2 - 80)
    :addTo(self)

    for i=1,#digitals do
    	--[[
    	 content = BubbleButton.new({
	        image = "digital_study/digital_bg.png",
	        sound = nil,
	        prepare = function()
	        end,
	        listener = function()
	        end,
	   	})
    	:setScale(0.3)
    	:pos(size.width / 11 * i + (-size.width / 2),-size.height / 2 + 100)
	   	:setTouchSwallowEnabled(false) 
	   	:addTo(self)
		--]]

	   	content = cc.ui.UIPushButton.new({ normal = "bird/digital_bg.png", pressed = "bird/digital_bg.png"})
	    :onButtonClicked(function()
	    	--播放音效
	    	playSound(tostring(digitals[i]))
	    end)
	    :setScale(0.3)
	    :pos(size.width / 11 * i + (-size.width / 2),-size.height / 2 + 130)
	    :setTouchSwallowEnabled(false) 
	    :addTo(self)

	   	CCLabelAtlas:_create(""..digitals[i],"common/digital.png",76,115,string.byte('0'))
		:setAnchorPoint(0.5,0.5)
		:addTo(content)
    end

	self.continueButton = BubbleButton.new({
        image = "common/continue.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.continueButton:setButtonEnabled(false)
        end,
        listener = function()
            if g_mainScene ~= nil then

                local layer = self:getParent()
                if layer.param ~= nil then
                    local newLayer = require(self:getParent().modname).new(layer.param)
                    :addTo(g_mainScene)
                else
                    local newLayer = require(self:getParent().modname).new()
                    :addTo(g_mainScene)
                end
                
                layer:removeFromParent()
            end
        end,
    })
    :pos(-200, -size.height / 2)
    :addTo(self)

	self.backButton = BubbleButton.new({
        image = "common/back.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
            display.replaceScene(require("app.scenes.MainScene").new(), "fade", 0.6, display.COLOR_WHITE)
        end,
    })
    :pos(200, -size.height / 2)
    :addTo(self)
end


return ResultPanel