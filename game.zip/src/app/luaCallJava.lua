--停止录音
function stopListening( )
  if device.platform == "android" then
      local javaClassName = "org/cocos2dx/lua/Iat"
      local javaMethodName = "stopListening"
      --local javaParams = {levelFileData["level_speech_array"][pageIdx],pageIdx}
      local javaParams = {}
      local javaMethodSig = "()V"
      local callok,result = luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
  end
end

--停止说话
function stopSpeeking()
  if device.platform == "android" then
      local javaClassName = "org/cocos2dx/lua/Tts"
      local javaMethodName = "stopSpeeking"
      local javaParams = {}
      local javaMethodSig = "()V"
      local callok,result = luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
  end
end

--获取网络状态
function getNetWorkStatus()
  if device.platform == "android" then
      local javaClassName = "org/cocos2dx/lua/AppActivity"
      local javaMethodName = "isNetWorkOk"
      --local javaParams = {levelFileData["level_speech_array"][pageIdx],pageIdx}
      local javaParams = {}
      local javaMethodSig = "()Z"
      local callok,result = luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
      if callok == true then
        return result
      else
        print("call failure ..".. result)
        return nil
      end 
  end
end

--调用java声音播放接口
function callbackPlay(str,tag)
	if device.platform == "android" and getNetWorkStatus() == true then
      local javaClassName = "org/cocos2dx/lua/AppActivity"
      local javaMethodName = "SpeechSynthesis"
      --local javaParams = {levelFileData["level_speech_array"][pageIdx],pageIdx}
      local javaParams = {str,tag}
      local javaMethodSig = "(Ljava/lang/String;I)V"
      return luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
  	end

    return false
end

function playLevelSound(str,tag)
	return callbackPlay(str,tag)
end

function playSound(str)
	return callbackPlay(str, 0)
end

--获取科大讯飞的录音状态
function getSpeechingStatus()
    if device.platform == "android" then
      local javaClassName = "org/cocos2dx/lua/Iat"
      local javaMethodName = "getIatStatus"
      --local javaParams = {levelFileData["level_speech_array"][pageIdx],pageIdx}
      local javaParams = {}
      local javaMethodSig = "()Z"
      local callok,result = luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
      if callok == true then
        return result
      else
        print("call failure ..".. result)
        return nil
      end
    end
end

--pop信息
function showTip(str)
    if device.platform == "android" then
      local javaClassName = "org/cocos2dx/lua/AppActivity"
      local javaMethodName = "showTip"
      --local javaParams = {levelFileData["level_speech_array"][pageIdx],pageIdx}
      local javaParams = {str}
      local javaMethodSig = "(Ljava/lang/String;)V"
      luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
    end
end