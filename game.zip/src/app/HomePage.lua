require("app.HomeGamesButton")
require("app.LevelSelect")
require("app.GlobalData")
local BubbleButton = import("app.common.BubbleButton")

HomePage = class("HomePage", function()
    return display.newLayer()
end)

function HomePage:ctor()
	local bg = display.newSprite("home/bg.png")
	:pos(display.cx, display.cy)

	local size = bg:getContentSize()
	bg:setScale(display.cx * 2 / size.width, display.cy * 2 / size.height)
	bg:addTo(self)


	--播放粒子效果
	local particle1 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx / 4 * 2,display.cy * 2 - 100)
	:addTo(self)

	local particle2 = cc.ParticleSystemQuad:create("particles/snow.plist")
	:pos(display.cx / 4 * 3,display.cy * 2 - 100)
	:addTo(self)

	--学数字
	self.btStudyDigital = HomeGamesButton.new("home/xsz.png","home/xsz_title.png",function ()
		local levelSelect = LevelSelect.new(study_digital,1)
		:addTo(self:getParent())
		self:removeFromParent()
	end)
	:pos(230 + 170 ,display.cy * 2 - 80)
	:addTo(self)

	--学字母
	self.btStudyLetter = HomeGamesButton.new("home/xzm.png","home/xzm_title.png",function ()
		local levelSelect = LevelSelect.new(study_letter,2)
		:addTo(self:getParent())
		self:removeFromParent()
	end)
	:pos(230 + 340,display.cy * 2 - 80)
	:addTo(self)

	--去哪儿
	self.btGoWhere = HomeGamesButton.new("home/qn.png","home/qn_title.png",function ()
		print("=====敬请期待=======")
	end)
	:pos(230 + 510,display.cy * 2 - 80)
	:addTo(self)

	--学诗词
	self.btReadPoetry = HomeGamesButton.new("home/xsg.png","home/ds_title.png",function ()
		print("=====敬请期待=======")
	end)
	:pos(230 + 170,display.cy * 2 - 290)
	:addTo(self)

	--学跳舞
	self.btStudyDance = HomeGamesButton.new("home/xtw.png","home/xtw_title.png",function ()
		print("=====敬请期待=======")
	end)
	:pos(230 + 340,display.cy * 2 - 290)
	:addTo(self)

	--学..
	self.btStudy = HomeGamesButton.new("home/ddy.png","home/ddy_title.png",nil)
	:pos(230 + 510,display.cy * 2 - 290)
	:setVisible(false)
	:addTo(self)
	--]]

	--添加返回按钮
	self.backButton = BubbleButton.new({
        image = "home/back.png",
        sound = nil,
        prepare = function()
            --audio.playSound(GAME_SFX.tapButton)
            self.backButton:setButtonEnabled(false)
        end,
        listener = function()
            os.exit()
        end,
    })
    :pos(340, 50)
    :addTo(self)

end

return HomePage